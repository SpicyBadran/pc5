#include "allocator/PeImportFirst.hpp"

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

constexpr std::size_t PeOffset = 0x40;
constexpr std::size_t OptionalOffset = PeOffset + 24;
constexpr std::size_t OptionalBytes = 240;
constexpr std::uint32_t SectionRva = 0x1000;
constexpr std::size_t SectionOffset = 0x200;
constexpr std::size_t SectionBytes = 0x200;
constexpr std::size_t DescriptorBytes = 20;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void put16(std::vector<unsigned char>& bytes, std::size_t offset, std::uint16_t value) {
    std::memcpy(bytes.data() + offset, &value, sizeof(value));
}

void put32(std::vector<unsigned char>& bytes, std::size_t offset, std::uint32_t value) {
    std::memcpy(bytes.data() + offset, &value, sizeof(value));
}

std::uint32_t get32(const std::vector<unsigned char>& bytes, std::size_t offset) {
    std::uint32_t value = 0;
    std::memcpy(&value, bytes.data() + offset, sizeof(value));
    return value;
}

std::vector<unsigned char> image(const std::vector<std::string>& dlls, std::uint16_t magic = 0x20b, std::uint32_t directories = 16, std::uint16_t optionalBytes = OptionalBytes, std::uint32_t sectionRva = SectionRva) {
    std::vector<unsigned char> bytes(SectionOffset + SectionBytes, 0);
    bytes[0] = 'M';
    bytes[1] = 'Z';
    put32(bytes, 0x3c, PeOffset);
    put32(bytes, PeOffset, 0x00004550u);
    put16(bytes, PeOffset + 4, 0x8664);
    put16(bytes, PeOffset + 6, 1);
    put16(bytes, PeOffset + 20, optionalBytes);
    put16(bytes, OptionalOffset, magic);
    put32(bytes, OptionalOffset + 108, directories);
    put32(bytes, OptionalOffset + 112 + 8, sectionRva);
    put32(bytes, OptionalOffset + 112 + 12, static_cast<std::uint32_t>((dlls.size() + 1) * DescriptorBytes));
    const auto sectionTable = OptionalOffset + optionalBytes;
    std::memcpy(bytes.data() + sectionTable, ".idata", 6);
    put32(bytes, sectionTable + 8, SectionBytes);
    put32(bytes, sectionTable + 12, sectionRva);
    put32(bytes, sectionTable + 16, SectionBytes);
    put32(bytes, sectionTable + 20, SectionOffset);
    auto name = (dlls.size() + 1) * DescriptorBytes;
    for (std::size_t index = 0; index < dlls.size(); ++index) {
        const auto descriptor = SectionOffset + index * DescriptorBytes;
        put32(bytes, descriptor, static_cast<std::uint32_t>(sectionRva + 0x100 + index * 0x10));
        put32(bytes, descriptor + 4, static_cast<std::uint32_t>(index + 1));
        put32(bytes, descriptor + 12, static_cast<std::uint32_t>(sectionRva + name));
        put32(bytes, descriptor + 16, static_cast<std::uint32_t>(sectionRva + 0x180 + index * 0x10));
        std::memcpy(bytes.data() + SectionOffset + name, dlls[index].c_str(), dlls[index].size() + 1);
        name += dlls[index].size() + 1;
    }
    return bytes;
}

std::string importName(const std::vector<unsigned char>& bytes, std::size_t index, std::uint32_t sectionRva = SectionRva) {
    const auto rva = get32(bytes, SectionOffset + index * DescriptorBytes + 12);
    return reinterpret_cast<const char*>(bytes.data() + SectionOffset + (rva - sectionRva));
}

std::vector<unsigned char> descriptor(const std::vector<unsigned char>& bytes, std::size_t index) {
    const auto first = bytes.begin() + static_cast<std::ptrdiff_t>(SectionOffset + index * DescriptorBytes);
    return {first, first + static_cast<std::ptrdiff_t>(DescriptorBytes)};
}

void writeFile(const std::filesystem::path& path, const std::vector<unsigned char>& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    require(static_cast<bool>(output), "cannot write " + path.string());
}

std::vector<unsigned char> readFile(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "cannot read " + path.string());
    return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}

void movesTheNamedImportFirst() {
    const auto original = image({"kernel32.dll", "ucrtbase.dll", "mimalloc-redirect.dll", "advapi32.dll"});
    auto moved = original;
    Allocator::MoveImportFirst(moved, "MIMALLOC-REDIRECT.dll");
    require(importName(moved, 0) == "mimalloc-redirect.dll" && importName(moved, 1) == "kernel32.dll" && importName(moved, 2) == "ucrtbase.dll" && importName(moved, 3) == "advapi32.dll",
        "the named import did not move first, or the others changed their order");
    require(descriptor(moved, 0) == descriptor(original, 2) && descriptor(moved, 1) == descriptor(original, 0) && descriptor(moved, 2) == descriptor(original, 1) && descriptor(moved, 3) == descriptor(original, 3),
        "a descriptor did not move whole");
    const auto directoryEnd = SectionOffset + 4 * DescriptorBytes;
    require(std::equal(moved.begin(), moved.begin() + SectionOffset, original.begin()) && std::equal(moved.begin() + directoryEnd, moved.end(), original.begin() + directoryEnd),
        "bytes outside the import descriptors changed");
    auto unchanged = original;
    Allocator::MoveImportFirst(unchanged, "kernel32.dll");
    require(unchanged == original, "moving the first import changed the image");
}

void movesTheImportFirstWithATwoDirectoryOptionalHeader(const std::filesystem::path& directory) {
    const auto original = image({"kernel32.dll", "ucrtbase.dll", "mimalloc-redirect.dll", "advapi32.dll"}, 0x20b, 2, 128);
    auto moved = original;
    Allocator::MoveImportFirst(moved, "mimalloc-redirect.dll");
    require(importName(moved, 0) == "mimalloc-redirect.dll" && importName(moved, 1) == "kernel32.dll" && importName(moved, 2) == "ucrtbase.dll" && importName(moved, 3) == "advapi32.dll",
        "the import did not move first with a 128-byte optional header holding two directories");
    require(descriptor(moved, 0) == descriptor(original, 2) && descriptor(moved, 1) == descriptor(original, 0) && descriptor(moved, 2) == descriptor(original, 1) && descriptor(moved, 3) == descriptor(original, 3),
        "a descriptor did not move whole with a 128-byte optional header");
    const auto directoryEnd = SectionOffset + 4 * DescriptorBytes;
    require(std::equal(moved.begin(), moved.begin() + SectionOffset, original.begin()) && std::equal(moved.begin() + directoryEnd, moved.end(), original.begin() + directoryEnd),
        "bytes outside the import descriptors changed with a 128-byte optional header");
    auto repeated = moved;
    Allocator::MoveImportFirst(repeated, "mimalloc-redirect.dll");
    require(repeated == moved, "repeating the move changed the image with a 128-byte optional header");
    const auto path = directory / "two-directory.dll";
    writeFile(path, original);
    Allocator::MoveImportFirstInFile(path, "mimalloc-redirect.dll");
    require(readFile(path) == moved, "the file move differs from the in-memory move with a 128-byte optional header");
    Allocator::MoveImportFirstInFile(path, "mimalloc-redirect.dll");
    require(readFile(path) == moved, "repeating the move changed the file with a 128-byte optional header");
}

void movesTheImportInASectionEndingAboveFourGiB() {
    constexpr std::uint32_t highSectionRva = 0xFFFFF000u;
    auto original = image({"kernel32.dll", "mimalloc-redirect.dll", "advapi32.dll"}, 0x20b, 16, OptionalBytes, highSectionRva);
    put32(original, OptionalOffset + OptionalBytes + 8, 0x2000);
    auto moved = original;
    Allocator::MoveImportFirst(moved, "mimalloc-redirect.dll");
    require(importName(moved, 0, highSectionRva) == "mimalloc-redirect.dll" && importName(moved, 1, highSectionRva) == "kernel32.dll" && importName(moved, 2, highSectionRva) == "advapi32.dll",
        "the import in a section ending above 4 GiB did not move first");
}

void movesTheImportInAFile(const std::filesystem::path& directory) {
    const auto path = directory / "moved.dll";
    writeFile(path, image({"kernel32.dll", "mimalloc-redirect.dll"}));
    Allocator::MoveImportFirstInFile(path, "mimalloc-redirect.dll");
    const auto moved = readFile(path);
    require(importName(moved, 0) == "mimalloc-redirect.dll" && importName(moved, 1) == "kernel32.dll", "the file's import did not move first");
}

void failsWithoutTouchingTheFile(const std::filesystem::path& directory, const std::string& what, const std::vector<unsigned char>& bytes, const std::string& expected) {
    const auto path = directory / (what + ".dll");
    writeFile(path, bytes);
    try {
        Allocator::MoveImportFirstInFile(path, "mimalloc-redirect.dll");
    } catch (const std::exception& error) {
        require(std::string(error.what()).find(expected) != std::string::npos, what + ": failed with another error: " + error.what());
        require(readFile(path) == bytes, what + ": the file changed although the move failed");
        return;
    }
    throw std::runtime_error(what + ": the move did not fail");
}

void failsWithoutTouchingTheImage(const std::string& what, const std::vector<unsigned char>& bytes, const std::string& expected) {
    auto copy = bytes;
    try {
        Allocator::MoveImportFirst(copy, "mimalloc-redirect.dll");
    } catch (const std::exception& error) {
        require(std::string(error.what()).find(expected) != std::string::npos, what + ": failed with another error: " + error.what());
        require(copy == bytes, what + ": the image changed although the move failed");
        return;
    }
    throw std::runtime_error(what + ": the move did not fail");
}

}

int main() {
    auto directory = std::filesystem::temp_directory_path() / std::filesystem::path(u8"aps5-pe-import-first-a\u00e7\u00e3o-\u65e5\u672c-");
    directory += std::to_string(std::random_device{}());
    try {
        std::filesystem::create_directories(directory);
        movesTheNamedImportFirst();
        movesTheImportInASectionEndingAboveFourGiB();
        movesTheImportFirstWithATwoDirectoryOptionalHeader(directory);
        movesTheImportInAFile(directory);
        failsWithoutTouchingTheFile(directory, "missing-import", image({"kernel32.dll", "ucrtbase.dll"}), "does not import mimalloc-redirect.dll");
        auto truncated = image({"kernel32.dll", "mimalloc-redirect.dll", "ucrtbase.dll"});
        truncated.resize(SectionOffset + DescriptorBytes + DescriptorBytes / 2);
        failsWithoutTouchingTheImage("truncated-directory", truncated, "truncated import directory");
        failsWithoutTouchingTheImage("pe32", image({"kernel32.dll", "mimalloc-redirect.dll"}, 0x10b), "not a PE32+ image");
        auto undeclared = image({"kernel32.dll", "mimalloc-redirect.dll"});
        put32(undeclared, OptionalOffset + 108, 0);
        failsWithoutTouchingTheImage("directory-count-zero", undeclared, "the image has no imports");
        auto oneDirectory = image({"kernel32.dll", "mimalloc-redirect.dll"});
        put32(oneDirectory, OptionalOffset + 108, 1);
        failsWithoutTouchingTheImage("directory-count-one", oneDirectory, "the image has no imports");
        auto shortHeader = image({"kernel32.dll", "mimalloc-redirect.dll"});
        put16(shortHeader, PeOffset + 20, 112);
        failsWithoutTouchingTheImage("optional-header-without-imports", shortHeader, "the image has no imports");
        auto incompleteEntry = image({"kernel32.dll", "mimalloc-redirect.dll"}, 0x20b, 2, 128);
        put16(incompleteEntry, PeOffset + 20, 127);
        failsWithoutTouchingTheImage("optional-header-incomplete-import-entry", incompleteEntry, "the image has no imports");
        auto unterminated = image({"kernel32.dll", "mimalloc-redirect.dll"});
        unterminated.resize(SectionOffset + 3 * DescriptorBytes + 13 + 21);
        failsWithoutTouchingTheImage("unterminated-name", unterminated, "unterminated import name");
        auto outsideFile = image({"kernel32.dll", "mimalloc-redirect.dll", "ucrtbase.dll"});
        put32(outsideFile, SectionOffset + 2 * DescriptorBytes + 12, static_cast<std::uint32_t>(SectionRva + 0x1ff));
        outsideFile.resize(0x300);
        failsWithoutTouchingTheImage("name-past-the-file", outsideFile, "RVA outside the file data");
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        std::error_code ignored;
        std::filesystem::remove_all(directory, ignored);
        return 1;
    }
    std::filesystem::remove_all(directory);
    std::cout << "pe import first tests passed\n";
    return 0;
}
