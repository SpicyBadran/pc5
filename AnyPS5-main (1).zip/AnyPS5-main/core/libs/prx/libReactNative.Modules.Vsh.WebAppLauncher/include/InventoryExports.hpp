#pragma once

#include "SceTypes.hpp"

extern "C" {

int APS5_VABI CheckSystemEvents();
int APS5_VABI CommerceDialogBrowseCategory();
int APS5_VABI CommerceDialogBrowseProduct();
int APS5_VABI CommerceDialogInit();
int APS5_VABI CommerceDialogRedeemPromotionCode();
int APS5_VABI CommerceHidePsStoreIcon();
int APS5_VABI CommerceSetPsStoreIconLayout();
int APS5_VABI CommerceShowPsStoreIcon();
int APS5_VABI DisableSystemMedia();
int APS5_VABI ErrorDialogClose();
int APS5_VABI ErrorDialogInit();
int APS5_VABI ErrorDialogOpen();
int APS5_VABI GetAccountAgeA();
int APS5_VABI GetAccountCountryA();
int APS5_VABI GetAccountIdA();
int APS5_VABI GetAccountLanguage2();
int APS5_VABI GetAuthorizationCode();
int APS5_VABI GetClosedCaptionSettings();
int APS5_VABI GetOnlineId();
int APS5_VABI GetProcessTime();
int APS5_VABI GetVideoOutputStatus();
int APS5_VABI GetVideoOutputStatusInt();
int APS5_VABI Hide();
int APS5_VABI IsDebuggingSupported();
int APS5_VABI NpWebAbortRequest();
int APS5_VABI NpWebDeleteRequest();
int APS5_VABI NpWebInitialize();
int APS5_VABI NpWebReadData();
int APS5_VABI NpWebTerminate();
int APS5_VABI OpenClosedCaptionAdvancedSettings();
int APS5_VABI OpenClosedCaptionSettings();
int APS5_VABI SoundInitialize();
int APS5_VABI SoundLoad();
int APS5_VABI SoundPlay();
int APS5_VABI SoundTerminate();
int APS5_VABI SpeechCancel();
int APS5_VABI SpeechClose();
int APS5_VABI SpeechInitialize();
int APS5_VABI SpeechSpeak();
int APS5_VABI SpeechStatus();
int APS5_VABI SpeechTerminate();
int APS5_VABI SystemDialogInit();
int APS5_VABI SystemDialogOpen();
int APS5_VABI SystemServiceParamGetInt();
int APS5_VABI SystemServiceParamGetString();


int APS5_VABI EnableSystemMusic();
int APS5_VABI SpeechSystemSettings();
int APS5_VABI libReactNativeWebAppLauncherInventory_41blU2JCqLQ_nid_no_patch();
int APS5_VABI GetAccountPsPlusStatus();
int APS5_VABI RegisterSystemEventCallback();
int APS5_VABI GetNetworkConnectionType();
int APS5_VABI NpWebSendRequest();
int APS5_VABI DisableSystemMusic();
int APS5_VABI EnableSystemMedia();
int APS5_VABI CommerceDialogCheckout();
int APS5_VABI CommerceDialogBrowsePsPlus();
int APS5_VABI NpWebCreateRequest();

}
