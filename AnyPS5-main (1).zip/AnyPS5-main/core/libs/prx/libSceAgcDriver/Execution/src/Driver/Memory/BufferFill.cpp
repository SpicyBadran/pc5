#include "prx/libSceAgcDriver/Execution/include/Driver/Driver.hpp"
#include "prx/libSceAgcDriver/Execution/include/Driver/Memory/BufferFill.hpp"
#include "prx/libSceAgcDriver/Execution/include/Mutex.hpp"
#include "ThreadOwned.hpp"
#include "prx/libSceAgcDriver/Execution/include/Driver/Diagnostics.hpp"
#include "prx/libSceAgcDriver/Execution/include/Driver/Memory/DwordPatternFill.hpp"
#include "prx/libSceAgcDriver/Execution/include/Driver/Draw/DrawPipeline.hpp"
#include "prx/libSceAgcDriver/Execution/include/GuestMemory.hpp"
#include <algorithm>
#include "prx/libSceAgcDriver/Graphics/include/DepthSurface.hpp"
#include "prx/libSceAgcDriver/Graphics/include/MultisampleTarget.hpp"
#include <bit>
#include <cstdlib>
#include <initializer_list>
#include <optional>
#include <cstring>

namespace AgcDriver::DriverDetail {

namespace {

bool matchesDwordPatternFillKernel(std::span<const std::uint32_t> code) {
    static constexpr std::array<std::uint32_t, 69> kernel{
        0xbfa00003u, 0xd7460002u, 0x04010c0au, 0x7da80408u, 0xbf88003fu, 0x7e000c09u, 0xbf070980u, 0x858a807eu,
        0x7e005700u, 0x100000ffu, 0x4f800000u, 0x7e060f00u, 0xd5766a00u, 0x02020609u, 0x7d8a0280u, 0x4c020080u,
        0x02000101u, 0xd56a0001u, 0x00020700u, 0x4c000303u, 0x4a020303u, 0x02000101u, 0xd56a0000u, 0x00020500u,
        0xd5690001u, 0x00020009u, 0x4c060302u, 0x7d860609u, 0x7d8c02f9u, 0x06068c02u, 0x87ea6a0cu, 0x50000080u,
        0xd5286a00u, 0x003200c1u, 0xd5010000u, 0x002a00c1u, 0xd5690000u, 0x00020009u, 0x4c000102u, 0x7d0a0080u,
        0xbe88246au, 0xbf880015u, 0x7d0a0081u, 0xbe8a246au, 0xbf88000cu, 0x7d0a0082u, 0xbeea246au, 0xbf880003u,
        0x7e000207u, 0xe0102000u, 0x80000002u, 0x8afe7e6au, 0xbf880003u, 0x7e000206u, 0xe0102000u, 0x80000002u,
        0xbefe046au, 0x8afe7e0au, 0xbf880003u, 0x7e000205u, 0xe0102000u, 0x80000002u, 0xbefe040au, 0x8afe7e08u,
        0xbf880003u, 0x7e000204u, 0xe0102000u, 0x80000002u, 0xbf810000u};
    static constexpr std::size_t comparesAt = 27;
    static constexpr std::array<std::uint32_t, 3> comparesSwapped{0x7d8c02f9u, 0x06068c02u, 0x7d860609u};
    if (code.size() < kernel.size()) return false;
    const auto before = std::span(kernel).first(comparesAt);
    const auto after = std::span(kernel).subspan(comparesAt + comparesSwapped.size());
    const auto compares = code.subspan(comparesAt, comparesSwapped.size());
    if (!std::equal(before.begin(), before.end(), code.begin()) || !std::equal(after.begin(), after.end(), code.begin() + comparesAt + comparesSwapped.size())) return false;
    return std::equal(compares.begin(), compares.end(), kernel.begin() + comparesAt) || std::equal(compares.begin(), compares.end(), comparesSwapped.begin());
}

}

bool MatchesBufferPatternFillKernel(std::span<const std::uint32_t> code) {
    static constexpr std::array<std::uint32_t, 12> kernel{0xd7460004u, 0x04010c08u, 0xf4280002u, 0xfa000000u, 0xbf8cc07fu, 0x7e000200u, 0x7e020200u, 0x7e040200u, 0x7e060200u, 0xe01c2000u, 0x80000004u, 0xbf810000u};
    if (code.size() < kernel.size()) return false;
    const auto pattern = (code[2] >> 6u) & 0x7fu;
    if (pattern < 4u || pattern % 4u != 0 || pattern + 3u >= 106u || code[2] != (kernel[2] | (pattern << 6u))) return false;
    for (std::size_t word = 0; word < kernel.size(); ++word) {
        if (word == 2) continue;
        const auto move = word >= 5 && word <= 8 ? pattern + static_cast<std::uint32_t>(word - 5) : 0u;
        if (code[word] != (kernel[word] | move)) return false;
    }
    return true;
}

bool Driver::matchesFillKernel(std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    static const bool enabled = std::getenv("APS5_NO_FILL_HLE") == nullptr;
    static const bool patternEnabled = std::getenv("APS5_NO_PATTERN_FILL_HLE") == nullptr;
    if (!enabled || userData.size() < 8 || compute.numThreads[0] != 64 || compute.numThreads[1] != 1 || compute.numThreads[2] != 1) return false;
    if (patternEnabled && (MatchesPatternFillKernel(code, userData, compute) || MatchesGcnPatternFillKernel(code, userData, compute))) return true;
    static constexpr std::array<std::uint32_t, 9> fillKernel{0xd7460004u, 0x04010c08u, 0x7e000204u, 0x7e020205u, 0x7e040206u, 0x7e060207u, 0xe01c2000u, 0x80000004u, 0xbf810000u};
    if (!MatchesBufferPatternFillKernel(code) && (code.size() < fillKernel.size() || !std::equal(fillKernel.begin(), fillKernel.end(), code.begin()))) return false;

    const auto stride = (userData[1] >> 16u) & 0x3fffu;
    const bool swizzled = ((userData[1] >> 31u) & 1u) != 0;
    const auto dstSel = userData[3] & 0xfffu;
    const bool addTid = ((userData[3] >> 23u) & 1u) != 0;
    const auto type = userData[3] >> 30u;
    const auto format = (userData[3] >> 12u) & 0x7fu;
    return type == 0 && stride == 16 && !swizzled && !addTid && dstSel == 0xfacu && format == 0x4bu;
}

std::optional<DwordPatternFill> MatchDwordPatternFill(std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    static const bool enabled = std::getenv("APS5_NO_FILL_HLE") == nullptr;
    if (!enabled || userData.size() != 10 || packet.size() < 5 || !compute.groupIdEnable[0] || compute.numThreads[0] != 64 || compute.numThreads[1] != 1 || compute.numThreads[2] != 1) return std::nullopt;
    if (!matchesDwordPatternFillKernel(code)) return std::nullopt;
    const auto stride = (userData[1] >> 16u) & 0x3fffu;
    const bool swizzled = ((userData[1] >> 31u) & 1u) != 0;
    const bool addTid = ((userData[3] >> 23u) & 1u) != 0;
    const auto type = userData[3] >> 30u;
    const auto format = (userData[3] >> 12u) & 0x7fu;
    const auto period = userData[9];
    if (type != 0 || stride != 4 || swizzled || addTid || format < 20u || format > 22u || (period != 1u && period != 2u && period != 4u) || (packet[4] & 0x20u) != 0 || packet[2] != 1 || packet[3] != 1) return std::nullopt;
    const auto dwords = std::min<std::uint64_t>({static_cast<std::uint64_t>(packet[1]) * 64u, userData[8], userData[2]});
    const auto base = userData[0] | (static_cast<std::uint64_t>(userData[1] & 0xffffu) << 32u);
    if (dwords == 0 || dwords % 4u != 0 || base % 16u != 0) return std::nullopt;
    DwordPatternFill fill{base, static_cast<std::size_t>(dwords * 4u), {}};
    for (std::uint32_t i = 0; i < 4; ++i) fill.pattern[i] = userData[4 + i % period];
    return fill;
}

std::optional<DwordPatternFill> MatchConstantDwordFill(std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    static const bool enabled = std::getenv("APS5_NO_FILL_HLE") == nullptr;
    if (!enabled || userData.size() != 4 || packet.size() < 5 || !compute.groupIdEnable[0] || compute.numThreads[0] != 64 || compute.numThreads[1] != 1 || compute.numThreads[2] != 1) return std::nullopt;
    static constexpr std::array<std::uint32_t, 6> kernel{0xd7460000u, 0x04010c04u, 0x7e020200u, 0xe0102000u, 0x80000100u, 0xbf810000u};
    if (code.size() < kernel.size()) return std::nullopt;
    for (std::size_t word = 0; word < kernel.size(); ++word) {
        if ((word == 2 ? code[word] & ~0x1ffu : code[word]) != kernel[word]) return std::nullopt;
    }
    const auto source = code[2] & 0x1ffu;
    std::uint32_t value;
    if (source >= 0x80u && source <= 0xc0u) value = source - 0x80u;
    else if (source >= 0xc1u && source <= 0xd0u) value = 0u - (source - 0xc0u);
    else return std::nullopt;
    const auto stride = (userData[1] >> 16u) & 0x3fffu;
    const bool swizzled = ((userData[1] >> 31u) & 1u) != 0;
    const bool addTid = ((userData[3] >> 23u) & 1u) != 0;
    const auto outOfBounds = (userData[3] >> 28u) & 3u;
    const auto format = (userData[3] >> 12u) & 0x7fu;
    const auto type = userData[3] >> 30u;
    if (type != 0 || stride != 4 || swizzled || addTid || outOfBounds != 0 || format < 20u || format > 22u || (packet[4] & 0x20u) != 0 || packet[2] != 1 || packet[3] != 1) return std::nullopt;
    const auto dwords = std::min<std::uint64_t>(static_cast<std::uint64_t>(packet[1]) * 64u, userData[2]);
    const auto base = userData[0] | (static_cast<std::uint64_t>(userData[1] & 0xffffu) << 32u);
    if (dwords == 0 || dwords % 4u != 0 || base % 16u != 0) return std::nullopt;
    DwordPatternFill fill{base, static_cast<std::size_t>(dwords * 4u), {}};
    fill.pattern.fill(value);
    return fill;
}

std::optional<DwordPatternFill> MatchClampedGlobalFill(std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    static const bool enabled = std::getenv("APS5_NO_FILL_HLE") == nullptr;
    if (!enabled || userData.size() != 6 || packet.size() < 5 || !compute.groupIdEnable[0] || compute.numThreads != std::array<std::uint32_t, 3>{64, 1, 1} || compute.threadIdComponentCount != 1) return std::nullopt;
    static constexpr std::array<std::uint32_t, 11> kernel{0xd7460000u, 0x04010c06u, 0x7e080205u, 0x7e0a0205u, 0x7e0c0205u, 0x7e0e0205u, 0x34000084u, 0x26000004u, 0xdc788000u, 0x00020400u, 0xbf810000u};
    if (code.size() < kernel.size() || !std::equal(kernel.begin(), kernel.end(), code.begin())) return std::nullopt;
    if ((packet[4] & 0x20u) != 0 || packet[2] != 1 || packet[3] != 1) return std::nullopt;
    const auto base = userData[2] | (static_cast<std::uint64_t>(userData[3]) << 32u);
    const auto maxOffset = userData[4];
    const auto bytes = std::min<std::uint64_t>(static_cast<std::uint64_t>(packet[1]) * 64u * 16u, static_cast<std::uint64_t>(maxOffset) + 16u);
    if (bytes == 0 || base % 16u != 0 || maxOffset % 16u != 0) return std::nullopt;
    DwordPatternFill fill{base, static_cast<std::size_t>(bytes), {}};
    fill.pattern.fill(userData[5]);
    return fill;
}

std::optional<Graphics::MemoryValueFill> MatchMemoryValueBufferFill(std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    static const bool enabled = std::getenv("APS5_NO_FILL_HLE") == nullptr;
    if (!enabled || userData.size() != 8 || packet.size() < 5 || (packet[4] & 0x20u) != 0 || !compute.groupIdEnable[0]) return std::nullopt;
    const auto fill = Graphics::MatchMemoryValueFill(code, userData, compute.numThreads, {packet[1], packet[2], packet[3]});
    if (!fill) return std::nullopt;
    if (fill->address % 16u != 0 || fill->bytes % 16u != 0) return std::nullopt;
    return fill;
}

bool IsByteFill(const std::array<std::uint32_t, 4>& pattern) {
    return std::all_of(pattern.begin(), pattern.end(), [&](std::uint32_t word) { return word == (pattern[0] & 0xffu) * 0x01010101u; });
}

std::optional<Graphics::DccKeys> KeysFillMemo(const std::array<std::uint32_t, 4>& pattern, bool coversStorageKeys, bool memoryValueFill) {
    if (!IsByteFill(pattern) || !(coversStorageKeys || memoryValueFill)) return std::nullopt;
    switch (pattern[0] & 0xffu) {
        case 0x00: return Graphics::DccKeys::Clear0000;
        case 0x40: return Graphics::DccKeys::Clear0001;
        case 0x80: return Graphics::DccKeys::Clear1110;
        case 0xc0: return Graphics::DccKeys::Clear1111;
        case 0x20: return Graphics::DccKeys::ClearRegister;
        case 0xff: return Graphics::DccKeys::Uncompressed;
        default: return std::nullopt;
    }
}

std::optional<DwordPatternFill> MatchSgprPatternFill(std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute) {
    if (userData.size() != 9 || packet.size() < 5 || !compute.groupIdEnable[0] || compute.numThreads[0] != 64 || compute.numThreads[1] != 1 || compute.numThreads[2] != 1) return std::nullopt;
    static constexpr std::array<std::uint32_t, 23> kernel{
        0xbfa00001u, 0xd7460004u, 0x04010c09u, 0x7e000204u, 0x7e020205u, 0x7e040206u, 0x7e060207u, 0x7da80808u,
        0xbf88000du, 0x360a0883u, 0xbe84047eu, 0xbe86047eu, 0x7e100505u, 0x7da40a08u, 0xbefc0308u, 0x7e0c8700u,
        0x8a867e06u, 0xbefe0406u, 0xbf85fff9u, 0xbefe0404u, 0xe0102000u, 0x80000604u, 0xbf810000u};
    if (code.size() < kernel.size() || !std::equal(kernel.begin(), kernel.end(), code.begin())) return std::nullopt;
    const auto stride = (userData[1] >> 16u) & 0x3fffu;
    const bool swizzled = ((userData[1] >> 31u) & 1u) != 0;
    const bool addTid = ((userData[3] >> 23u) & 1u) != 0;
    const auto outOfBounds = (userData[3] >> 28u) & 3u;
    const auto format = (userData[3] >> 12u) & 0x7fu;
    const auto type = userData[3] >> 30u;
    if (type != 0 || stride != 4 || swizzled || addTid || outOfBounds > 1u || format < 20u || format > 22u || (packet[4] & 0x20u) != 0 || packet[2] != 1 || packet[3] != 1) return std::nullopt;
    const auto dwords = std::min<std::uint64_t>({static_cast<std::uint64_t>(packet[1]) * 64u, userData[8], userData[2]});
    if (dwords == 0) return std::nullopt;
    const auto base = userData[0] | (static_cast<std::uint64_t>(userData[1] & 0xffffu) << 32u);
    return DwordPatternFill{base, static_cast<std::size_t>(dwords * 4u), {userData[4], userData[5], userData[6], userData[7]}};
}

bool Driver::fillClearEnabled() {
    static const bool enabled = std::getenv("APS5_NO_FILL_CLEAR") == nullptr;
    return enabled;
}

bool Driver::fillClearExactOnly() {
    static const bool exactOnly = std::getenv("APS5_FILL_CLEAR_EXACT_ONLY") != nullptr;
    return exactOnly;
}

void Driver::fillClearCount(const Graphics::StorageTexture::FillCoverage& coverage, std::size_t bytes, std::span<const std::uint32_t, 4> pattern, std::size_t discarded, bool cleared, const char* refusal) {
    static const bool profile = std::getenv("APS5_PROFILE_DRAW") != nullptr;
    if (!profile) return;
    using FillCover = Graphics::StorageTexture::FillCover;
    static constexpr std::array<const char*, 8> names{"none", "exact", "inside", "around", "straddle", "several", "keys", "layer"};
    static AgcDriver::Mutex countsMutex;
    static std::array<std::uint64_t, 8> counts{}, coverBytes{};
    static std::map<std::uint32_t, std::uint64_t> coveredFormats;
    static std::map<std::string, std::uint64_t> refusals;
    static std::map<std::uint32_t, std::uint64_t> keyCodes;
    static std::uint64_t clears = 0, clearedBytes = 0, layerClears = 0, withOthers = 0, othersInside = 0, discards = 0;
    static auto lastReport = std::chrono::steady_clock::now();
    std::lock_guard lock(countsMutex);
    const auto index = static_cast<std::size_t>(coverage.cover);
    ++counts[index];
    coverBytes[index] += bytes;
    if (coverage.image != nullptr) {
        ++coveredFormats[coverage.image->Descriptor().format];
        if (coverage.others != 0) ++withOthers;
        othersInside += coverage.inside;
    }
    if (coverage.cover == FillCover::Keys) {

        const auto word = pattern[0];
        const bool uniform = pattern[1] == word && pattern[2] == word && pattern[3] == word && word == (word & 0xffu) * 0x01010101u;
        ++keyCodes[uniform ? word & 0xffu : 0x100u];
    }
    discards += discarded;
    if (cleared) {
        ++clears;
        clearedBytes += bytes;
        if (coverage.cover == FillCover::Layer) ++layerClears;
    } else if (refusal != nullptr) {
        ++refusals[refusal];
    }
    const auto now = std::chrono::steady_clock::now();
    if (now - lastReport < std::chrono::seconds(10)) return;
    lastReport = now;
    std::string line = "[fill-cover] fills by cover (count/MiB):";
    for (std::size_t i = 0; i < names.size(); ++i) line += " " + std::string(names[i]) + " " + std::to_string(counts[i]) + "/" + std::to_string(coverBytes[i] >> 20u);
    line += "; covers with other images over the range " + std::to_string(withOthers) + " (" + std::to_string(othersInside) + " images wholly inside), pending results discarded as dead " + std::to_string(discards) + "; covers by guest format:";
    for (const auto& [format, count] : coveredFormats) line += " " + std::to_string(format) + ":" + std::to_string(count);
    line += "; key fills by code:";
    for (const auto& [code, count] : keyCodes) {
        char text[32];
        std::snprintf(text, sizeof(text), " 0x%02x:%llu", code, static_cast<unsigned long long>(count));
        line += text;
    }
    std::fprintf(stderr, "%s\n", line.c_str());
    line = "[fill-clear] " + std::to_string(clears) + " fills cleared on resident images (" + std::to_string(clearedBytes >> 20u) + " MiB not stored, " + std::to_string(layerClears) + " one array layer); covers refused:";
    for (const auto& [reason, count] : refusals) line += " " + reason + " " + std::to_string(count);
    std::fprintf(stderr, "%s\n", line.c_str());
}

namespace {

void drainPendingInputWrites(std::uint32_t queueId, std::initializer_list<std::pair<std::uint64_t, std::size_t>> inputs) {
    if (queueId != 0 || !DrawPipeline::Active()) return;
    auto& pipeline = DrawPipeline::Queue0();
    for (const auto& [address, bytes] : inputs) {
        if (!pipeline.Overlaps(address, bytes)) continue;
        pipeline.Drain(DrawPipeline::DrainReason::Capture, 0x15);
        return;
    }
}

}

bool Driver::fillBuffer(QueueState& queue, std::uint32_t queueId, std::span<const std::uint32_t> packet, std::span<const std::uint32_t> code, const std::vector<std::uint32_t>& userData, const ShaderRecompiler::ShaderComputeStageInfo& compute, const std::shared_ptr<VulkanDevice>& localDevice) {
    auto dwordFill = MatchDwordPatternFill(packet, code, userData, compute);
    if (!dwordFill) dwordFill = MatchConstantDwordFill(packet, code, userData, compute);
    if (!dwordFill) dwordFill = MatchClampedGlobalFill(packet, code, userData, compute);
    std::optional<Graphics::MemoryValueFill> memoryFill;
    if (!dwordFill) memoryFill = MatchMemoryValueBufferFill(packet, code, userData, compute);
    if (!dwordFill && !memoryFill && !matchesFillKernel(code, userData, compute)) return false;
    std::uint64_t base;
    std::size_t bytes;
    std::array<std::uint32_t, 4> pattern;
    std::unique_lock inputLock(GuestMemory::GpuMutex(), std::defer_lock);
    if (dwordFill) {
        base = dwordFill->base;
        bytes = dwordFill->bytes;
        pattern = dwordFill->pattern;
    } else if (memoryFill) {
        drainPendingInputWrites(queueId, {{memoryFill->valueAddress, 4}});
        GuestMemory::TagGpuLockSite(GuestMemory::GpuLockSite::Fill);
        inputLock.lock();
        recordLabelsForPacket(localDevice.get(), queueId);
        if (!GuestMemory::Accessible(reinterpret_cast<const void*>(memoryFill->valueAddress), 4)) return false;
        GuestMemory::Read(memoryFill->valueAddress, std::as_writable_bytes(std::span(pattern).first(1)), 4);
        std::fill(pattern.begin() + 1, pattern.end(), pattern[0]);
        base = memoryFill->address;
        bytes = memoryFill->bytes;
    } else if (MatchesPatternFillKernel(code, userData, compute) || MatchesGcnPatternFillKernel(code, userData, compute)) {
        const auto range = MatchesGcnPatternFillKernel(code, userData, compute) ? DecodeGcnPatternFillRange(userData, packet) : DecodePatternFillRange(userData, packet);
        if (!range) return false;
        if (range->invocations == 0) return true;
        drainPendingInputWrites(queueId, {{range->control, 8}, {range->source, 4}});
        GuestMemory::TagGpuLockSite(GuestMemory::GpuLockSite::Fill);
        inputLock.lock();
        recordLabelsForPacket(localDevice.get(), queueId);
        if (!GuestMemory::Accessible(reinterpret_cast<const void*>(range->control), 8)) return false;
        std::array<std::uint32_t, 2> control;
        GuestMemory::Read(range->control, std::as_writable_bytes(std::span(control)), 4);
        const auto count = range->UniformBytes(control[0], control[1]);
        if (!count) return false;
        if (*count == 0) return true;
        if (!GuestMemory::Accessible(reinterpret_cast<const void*>(range->source), 4)) return false;
        GuestMemory::Read(range->source, std::as_writable_bytes(std::span(pattern).first(1)), 4);
        std::fill(pattern.begin() + 1, pattern.end(), pattern[0]);
        base = range->destination;
        bytes = *count;
    } else {
        const auto numRecords = userData[2];
        std::array<std::uint32_t, 3> groups{packet[1], packet[2], packet[3]};
        if ((packet[4] & 0x20u) != 0) {
            for (std::uint32_t axis = 0; axis < 3; ++axis) {
                const auto threads = std::max(readRegister(queue.shader, 0x207 + axis) & 0xffffu, 1u);
                groups[axis] = ThreadDimensionGroups(groups[axis], threads);
            }
        }
        if (groups[1] != 1 || groups[2] != 1) return false;
        const auto records = std::min<std::uint64_t>(static_cast<std::uint64_t>(groups[0]) * 64u, numRecords);
        base = userData[0] | (static_cast<std::uint64_t>(userData[1] & 0xffffu) << 32u);
        bytes = static_cast<std::size_t>(records * 16u);
        if (MatchesBufferPatternFillKernel(code)) {
            const auto source = userData[4] | (static_cast<std::uint64_t>(userData[5] & 0xffffu) << 32u);
            drainPendingInputWrites(queueId, {{source, sizeof(pattern)}});
            GuestMemory::TagGpuLockSite(GuestMemory::GpuLockSite::Fill);
            inputLock.lock();
            recordLabelsForPacket(localDevice.get(), queueId);
            if (!GuestMemory::Accessible(reinterpret_cast<const void*>(source), sizeof(pattern))) return false;
            GuestMemory::Read(source, std::as_writable_bytes(std::span(pattern)), 4);
        } else {
            pattern = {userData[4], userData[5], userData[6], userData[7]};
        }
    }
    if (queueId == 0 && DrawPipeline::Active() && inputLock.owns_lock()) inputLock.unlock();
    storeBufferFill(queueId, base, bytes, pattern, localDevice, memoryFill.has_value(), true);
    return true;
}


void Driver::storeBufferFill(std::uint32_t queueId, std::uint64_t base, std::size_t bytes, const std::array<std::uint32_t, 4>& pattern, const std::shared_ptr<VulkanDevice>& localDevice, bool memoryValueFill, bool noteMetadata) {
    static const bool profile = std::getenv("APS5_PROFILE_DRAW") != nullptr;
    static std::atomic<std::uint64_t> fills{0}, filledBytes{0}, cpuFills{0};

    static std::uint64_t uniformFills = 0, uniformBytes = 0, patternFills = 0, patternBytes = 0, chainCopies = 0;

    enum FillPhase : std::size_t { FillLabels, FillCheck, FillClassify, FillDiscard, FillClearPhase, FillFlush, FillDevice, FillCpu, FillPhaseCount };
    static constexpr const char* fillPhaseNames[FillPhaseCount] = {"labels", "check", "classify", "discard", "clear", "flush", "device", "cpu"};
    static std::array<double, FillPhaseCount> fillPhaseMs{};
    static std::array<double, 8> holdByCoverMs{};
    static std::array<std::uint64_t, 8> holdByCover{};
    static std::uint64_t flushes = 0, flushed = 0, absorbedFills = 0, absorbedBytes = 0;
    static auto fillReport = std::chrono::steady_clock::now();
    ++fills;
    filledBytes += bytes;
    if (bytes == 0) return;
    const auto store = [this, queueId, base, bytes, pattern, localDevice, memoryValueFill, noteMetadata] {
        GuestMemory::TagGpuLockSite(GuestMemory::GpuLockSite::Fill);
        std::lock_guard gpuLock(GuestMemory::GpuMutex());
        const auto holdStart = profile ? std::chrono::steady_clock::now() : std::chrono::steady_clock::time_point{};
        auto phaseStart = holdStart;
        const auto phase = [&](FillPhase which) {
            if (!profile) return;
            const auto now = std::chrono::steady_clock::now();
            fillPhaseMs[which] += std::chrono::duration<double, std::milli>(now - phaseStart).count();
            phaseStart = now;
        };

    recordLabelsForPacket(localDevice.get(), queueId);
    phase(FillLabels);
    GuestMemory::CheckRange(reinterpret_cast<const void*>(base), bytes, 16, true);
    phase(FillCheck);
    const auto coverage = Graphics::StorageTexture::ClassifyFill(base, bytes);
    phase(FillClassify);

    static const bool traceKeys = std::getenv("APS5_TRACE_DCC_KEYS") != nullptr;
    if (traceKeys && coverage.cover == Graphics::StorageTexture::FillCover::Keys) std::fprintf(stderr, "[dcc-keys] title fills keys 0x%llx+0x%zx with %08x %08x %08x %08x (queue 0x%x)\n", static_cast<unsigned long long>(base), bytes, pattern[0], pattern[1], pattern[2], pattern[3], queueId);
    const bool uniformKeysFill = coverage.cover == Graphics::StorageTexture::FillCover::Keys && IsByteFill(pattern);
    if (uniformKeysFill) {
        Graphics::StorageTexture::NoteKeysFill(base, bytes, static_cast<std::uint8_t>(pattern[0]));
        Graphics::StorageTexture::ClearByKeysFill(base, bytes, static_cast<std::uint8_t>(pattern[0]));
    }

    const bool uniform = pattern[0] == pattern[1] && pattern[1] == pattern[2] && pattern[2] == pattern[3];
    const bool absorbable = uniform && coverage.cover == Graphics::StorageTexture::FillCover::None && Graphics::MultisampledColorFillAbsorbs(base, bytes, pattern[0]);
    if (uniform && !absorbable) static_cast<void>(Graphics::DiscardFilledDepthPlanes(base, bytes, pattern[0]));
    const auto discarded = fillClearEnabled() ? Graphics::StorageTexture::DiscardPendingInside(base, bytes) : 0u;
    phase(FillDiscard);
    const char* refusal = nullptr;
    bool cleared = false;
    if (coverage.image != nullptr) {
        if (!fillClearEnabled()) {
            refusal = "disabled";
        } else if (fillClearExactOnly() && (coverage.cover != Graphics::StorageTexture::FillCover::Exact || coverage.others != 0)) {
            refusal = "exact only";
        } else {

            Graphics::StorageTexture::FlushPending(base, bytes, coverage.image.get(), "buffer fill", Graphics::PublishScope::PartialUnits);
            cleared = coverage.image->FillClear(pattern, coverage.layer, refusal);
        }
    }
    phase(FillClearPhase);
    fillClearCount(coverage, bytes, pattern, discarded, cleared, refusal);
    noteForeignWriter(base, base + bytes, queueId);

    const bool absorbed = !cleared && absorbable;
    if (absorbed) {
        ++absorbedFills;
        absorbedBytes += bytes;
    } else if (!cleared) {
        ++flushes;

        if (Graphics::StorageTexture::FlushPending(base, bytes, nullptr, "buffer fill", Graphics::PublishScope::PartialUnits)) ++flushed;
    }
    phase(FillFlush);
    const bool stored = cleared || absorbed || localDevice->FillBuffer(base, bytes, pattern);
    phase(FillDevice);
    if (stored && !cleared && !absorbed) {
        if (const auto filled = KeysFillMemo(pattern, uniformKeysFill, memoryValueFill)) Graphics::NoteKeysFillOnGpu(base, bytes, *filled);
    }
    if (profile && stored && !cleared && !absorbed) {
        ++(uniform ? uniformFills : patternFills);
        (uniform ? uniformBytes : patternBytes) += bytes;
        if (!uniform) chainCopies += static_cast<std::uint64_t>(std::bit_width((bytes / 16) - 1));
    }
    if (!stored) {
        ++cpuFills;

        localDevice->WaitIdle();
        static thread_local std::vector<std::byte>* blockSlot = nullptr;
        auto& block = ShaderRecompiler::ThreadOwned(blockSlot);
        const auto chunk = std::min<std::size_t>(bytes, 1u << 20u);
        block.resize(chunk);
        for (std::size_t at = 0; at < chunk; at += 16) std::memcpy(block.data() + at, pattern.data(), 16);
        for (std::size_t done = 0; done < bytes; done += chunk) GuestMemory::Write(base + done, std::span<const std::byte>(block).first(std::min(chunk, bytes - done)), 16);
        phase(FillCpu);
    }
    if (noteMetadata && uniform) {
        Graphics::NoteDepthMetadataFill(base, bytes, pattern[0]);
        Graphics::NoteColorMetadataFill(base, bytes, pattern[0]);
    }
    if (profile) {
        const auto now = std::chrono::steady_clock::now();
        const auto cover = static_cast<std::size_t>(coverage.cover);
        ++holdByCover[cover];
        holdByCoverMs[cover] += std::chrono::duration<double, std::milli>(now - holdStart).count();
        if (now - fillReport > std::chrono::seconds(10)) {
            fillReport = now;
            static constexpr std::array<const char*, 8> coverNames{"none", "exact", "inside", "around", "straddle", "several", "keys", "layer"};
            std::string line;
            char text[64];
            for (std::size_t i = 0; i < FillPhaseCount; ++i) {
                std::snprintf(text, sizeof(text), " %s %.0f", fillPhaseNames[i], fillPhaseMs[i]);
                line += text;
            }
            char absorbedText[128];
            std::snprintf(absorbedText, sizeof(absorbedText), "; multisampled clears not stored %llu (%.0f MiB)", static_cast<unsigned long long>(absorbedFills), static_cast<double>(absorbedBytes) / 1048576.0);
            line += absorbedText;
            line += "; hold by cover (count/ms):";
            for (std::size_t i = 0; i < coverNames.size(); ++i) {
                std::snprintf(text, sizeof(text), " %s %llu/%.0f", coverNames[i], static_cast<unsigned long long>(holdByCover[i]), holdByCoverMs[i]);
                line += text;
            }
            std::fprintf(stderr, "[fill] %llu buffer fills (%.0f MiB), %llu stored by the CPU; hold phases ms (cumulative):%s; pre-store flushes %llu (%llu stored an image); stored on the GPU: uniform %llu (%.0f MiB), pattern %llu (%.0f MiB), chain copies %llu\n", static_cast<unsigned long long>(fills.load()), filledBytes.load() / 1048576.0, static_cast<unsigned long long>(cpuFills.load()), line.c_str(), static_cast<unsigned long long>(flushes), static_cast<unsigned long long>(flushed), static_cast<unsigned long long>(uniformFills), uniformBytes / 1048576.0, static_cast<unsigned long long>(patternFills), patternBytes / 1048576.0, static_cast<unsigned long long>(chainCopies));
        }
    }
    };
    static const bool orderedFills = std::getenv("APS5_PIPELINE_DRAIN_FILLS") == nullptr;
    if (orderedFills && queueId == 0 && DrawPipeline::Active()) {
        DrawPipeline::Queue0().Enqueue(DrawPipeline::CommitKind::BufferFill, [store, queueId] {
            GuestMemory::SetCurrentPacket(0x15, queueId);
            store();
        }, {{base, base + bytes}});
        return;
    }
    store();
}
}
