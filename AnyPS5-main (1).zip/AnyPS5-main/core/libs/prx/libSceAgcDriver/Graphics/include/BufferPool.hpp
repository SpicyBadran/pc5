#ifndef CORE_LIBS_PRX_LIBSCEAGCDRIVER_GRAPHICS_INCLUDE_BUFFERPOOL_HPP
#define CORE_LIBS_PRX_LIBSCEAGCDRIVER_GRAPHICS_INCLUDE_BUFFERPOOL_HPP

#include "prx/libSceAgcDriver/Graphics/include/Context.hpp"
#include "prx/libSceAgcDriver/Graphics/include/ImageMemory.hpp"
#include <array>
#include <chrono>
#include "prx/libSceAgcDriver/Execution/include/Mutex.hpp"
#include <cstdint>
#include <deque>
#include <list>
#include <memory>
#include <mutex>
#include <optional>
#include <unordered_map>
#include <vector>

namespace AgcDriver::Graphics {

struct BufferAllocation {
    VkBuffer buffer;
    VkDeviceMemory memory;
    void* mapping;
    VkDeviceAddress address;
    VkDeviceSize allocationBytes;
    std::size_t bytes;
    VkBufferUsageFlags usage;
    VkMemoryPropertyFlags properties = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    VkDeviceSize offset = 0;
    bool slab = false;
    std::size_t bufferBytes = 0;
    std::uint32_t memoryType = 0;
    bool hostPlaced = false;
};

struct SlabSlot {
    VkDeviceMemory memory;
    VkDeviceSize offset;
    void* mapping;
};

// Released buffer allocations kept for reuse, since creating, binding and mapping one costs tens of
// microseconds and a build makes several. Small requests are served by size class (the next power of
// two), so the many differently sized data and copied-region buffers of consecutive builds hit;
// requests of a MiB and more keep their exact size (the multi-MiB registered-range snapshots repeat
// exactly, and rounding them would waste pinned host memory). Retained allocations are evicted least
// recently used under a byte budget and a slot count, so a burst of small buffers between two large
// builds no longer sweeps the large ones out. Free slots are kept per size, usage and memory
// properties, so a lookup does not scan the other slots. Reuse is safe because a Buffer is only released once
// the GPU work using it completed (kept until the batch fence, or after a CommandBatch wait).
// APS5_NO_BUFFER_CLASSES=1 matches exact sizes only, as before; APS5_BUFFER_POOL_SLOTS=<n> sets the
// slot count (the bound applies to each tier below, and is held to a sixth of the device's
// maxMemoryAllocationCount so the three tiers keep half of it free).
//
// The size classes and the exact-size allocations are retained in two tiers with a budget each:
// the multi-MiB texture scratch buffers that come back from a batch (GPU-direct uploads and
// write-backs of storage images) filled the one budget, so every one returned evicted hundreds of
// the 256-byte copied-region buffers to fit, and those then missed on every build (81869 misses
// and 80850 evictions per run, each a Vulkan create or destroy under the pool mutex, 3.5 s per
// run). APS5_BUFFER_POOL_SHARED=1 keeps one tier as before.
class BufferPool {
public:
    explicit BufferPool(const Context& context);
    static VkDeviceSize DeviceBudget(const VkPhysicalDeviceMemoryProperties& memory, const VkPhysicalDeviceMemoryBudgetPropertiesEXT* reported = nullptr, bool integratedGpu = false);
    static VkDeviceSize ReclaimTarget(VkDeviceSize bytes);
    ~BufferPool();
    BufferPool(const BufferPool&) = delete;
    BufferPool& operator=(const BufferPool&) = delete;
    // The size a buffer for `bytes` is created with: its size class, or `bytes` itself when large.
    static std::size_t Capacity(std::size_t bytes);
    static VkBufferUsageFlags Usage(VkBufferUsageFlags usage, VkMemoryPropertyFlags properties);
    VkDeviceMemory AllocateMemory(const VkMemoryAllocateInfo& allocation, const char* operation, std::optional<std::uint32_t> hostType = std::nullopt, std::uint32_t* allocatedType = nullptr, bool newImage = false);
    ImageAllocation AllocateImage(const Context& context, VkImage image, const VkImageCreateInfo& imageInfo, const char* operation, bool newImage, bool budgeted);
    std::size_t ImageSlabBlocks();
    static VkDeviceSize ImageBudget(VkDeviceSize deviceBudget);
    VkDeviceMemory TakeImageMemory(const VkMemoryAllocateInfo& allocation, const char* operation, std::optional<std::uint32_t> hostType = std::nullopt, std::uint32_t* allocatedType = nullptr, bool newImage = false);
    void PutImageMemory(VkDeviceMemory memory, VkDeviceSize bytes, std::uint32_t memoryType) noexcept;
    std::size_t RetainedImages();
    std::optional<BufferAllocation> Take(std::size_t bytes, VkBufferUsageFlags usage, VkMemoryPropertyFlags properties = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, const char* category = nullptr, bool hostPlaced = false);
    void Put(const BufferAllocation& allocation) noexcept;
    VkDeviceSize ReclaimIdleDevice(VkDeviceSize bytes, std::chrono::steady_clock::time_point now);
    static bool SlabEligible(std::size_t capacity, VkDeviceSize alignment, VkDeviceSize size, VkDeviceSize atom);
    static VkDeviceSize SlabBlockBytes(std::size_t capacity);
    SlabSlot TakeSlot(const Context& context, std::uint32_t memoryType, std::size_t capacity, bool addressable);
    VkDeviceSize PutSlot(VkDeviceMemory memory, VkDeviceSize offset) noexcept;
    std::size_t SlabBlocks();

private:
    friend class ImageAllocation;
    VkDeviceMemory allocateMemoryWithReuse(const VkMemoryAllocateInfo& allocation, const char* operation, std::optional<std::uint32_t> hostType, std::uint32_t* allocatedType, bool newImage, const std::function<bool(std::uint32_t)>& reuse);
    static constexpr VkDeviceSize imageUnitBytes = 256;
    static constexpr VkDeviceSize imageBlockBytes = VkDeviceSize{4} << 20u;
    static constexpr std::uint32_t imageBlockUnits = static_cast<std::uint32_t>(imageBlockBytes / imageUnitBytes);
    struct ImageBlock {
        VkDeviceMemory memory = VK_NULL_HANDLE;
        std::uint32_t memoryType = 0;
        std::array<std::uint64_t, imageBlockUnits / 64> occupied{};
        std::uint32_t freeUnits = imageBlockUnits;
        std::uint32_t allocations = 0;
        std::uint32_t hint = 0;
        ImageBlock* previous = nullptr;
        ImageBlock* next = nullptr;
        bool retained = false;
    };
    ImageAllocation takeImageRange(const std::shared_ptr<BufferPool>& owner, std::uint32_t memoryType, VkDeviceSize bytes, VkDeviceSize alignment);
    static std::optional<std::uint32_t> imageRange(const ImageBlock& block, std::uint32_t units, std::uint32_t alignment);
    static void markImageRange(ImageBlock& block, std::uint32_t first, std::uint32_t units, bool occupied) noexcept;
    void linkImageBlock(ImageBlock& block) noexcept;
    void unlinkImageBlock(ImageBlock& block) noexcept;
    void releaseImageAllocation(const ImageAllocation& allocation) noexcept;
    VkDeviceSize trimImageBlocks();
    struct SlabBlock {
        VkDeviceMemory memory = VK_NULL_HANDLE;
        std::byte* mapping = nullptr;
        VkDeviceSize slotBytes = 0;
        std::vector<std::uint32_t> free;
        std::uint32_t used = 0;
        std::uint64_t slab = 0;
    };
    struct Slab {
        std::vector<SlabBlock*> available;
        std::size_t blocks = 0;
        std::size_t emptyBlocks = 0;
    };
    static std::uint64_t SlabKey(std::uint32_t memoryType, std::size_t capacity, bool addressable);
    void freeBlock(SlabBlock& block) noexcept;
    struct Slot {
        BufferAllocation allocation;
        std::uint64_t lastUse;
        std::list<Slot*>::iterator order;
    };
    struct SlotKey {
        std::size_t bytes;
        VkBufferUsageFlags usage;
        VkMemoryPropertyFlags properties;
        std::uint32_t memoryType = 0;
        bool hostPlaced = false;
        bool operator==(const SlotKey&) const = default;
    };
    struct SlotKeyHash {
        std::size_t operator()(const SlotKey& key) const noexcept {
            return std::hash<std::size_t>{}(key.bytes) ^ (static_cast<std::size_t>(key.usage) << 32u) ^ (static_cast<std::size_t>(key.properties) << 48u) ^ (static_cast<std::size_t>(key.memoryType) << 56u) ^ (static_cast<std::size_t>(key.hostPlaced) << 63u);
        }
    };
    // One retention tier: its slots by key (each list oldest first), their count and bytes, the
    // byte budget they are evicted under and its counters (APS5_PROFILE_DRAW, reported every 10 s
    // from Take).
    struct Tier {
        std::unordered_map<SlotKey, std::deque<Slot>, SlotKeyHash> free;
        std::size_t slots = 0;
        VkDeviceSize retainedBytes = 0;
        VkDeviceSize budget = 0;
        std::uint64_t hits = 0;
        std::uint64_t misses = 0;
        std::uint64_t evictions = 0;
    };
    // The tier a buffer of `capacity` and `properties` is retained in (the large one for everything
    // when shared; the device tier for device-local memory while it has a budget).
    Tier& tierFor(std::size_t capacity, VkMemoryPropertyFlags properties);
    static bool DeviceTierEnabled();
    static VkDeviceSize deviceBudget(const Context& context);
    static bool DeviceTiered(VkMemoryPropertyFlags properties);
    static std::size_t NextCapacity(std::size_t capacity);
    VkDeviceSize destroy(const BufferAllocation& allocation, bool retained = false) noexcept;
    VkDeviceSize trim();
    // Moves the tier's least recently used slot (the oldest front of its lists) to `evicted`; the
    // caller destroys those after releasing the mutex, so builds taking buffers on other threads
    // do not wait behind the Vulkan destroy calls. Nothing changes when the vector cannot grow.
    void evictOldest(Tier& tier, std::vector<BufferAllocation>& evicted);
    bool evictOldestImage(std::vector<BufferAllocation>& evicted);
    bool imagePooled(VkDeviceSize bytes, std::uint32_t memoryType) const;
    bool heapOverBudget();
    // The retained-slot bound of each tier (APS5_BUFFER_POOL_SLOTS, default `defaultSlots`), read once.
    static std::size_t MaxSlots();
    std::size_t maxSlots;
    VkDeviceSize (*cacheReclaim)(VkDeviceSize bytes, bool newImage);
    VkDevice device;
    PFN_vkUnmapMemory unmap;
    PFN_vkDestroyBuffer destroyBuffer;
    PFN_vkFreeMemory freeMemory;
    PFN_vkAllocateMemory allocateMemory;
    PFN_vkMapMemory mapMemory;
    VkPhysicalDevice physical = VK_NULL_HANDLE;
    VkPhysicalDeviceMemoryProperties memoryProperties{};
    PFN_vkGetPhysicalDeviceMemoryProperties2 memoryProperties2 = nullptr;
    AgcDriver::Mutex mutex;
    // Not `small`/`large`: <rpcndr.h> (via <windows.h>) defines `small` as a macro.
    Tier smallTier;
    Tier largeTier;
    Tier deviceTier;
    std::chrono::steady_clock::time_point heapRead{};
    bool heapOver = false;
    VkDeviceSize imageBudget = 0;
    VkDeviceSize imageBytes = 0;
    std::size_t imageSlots = 0;
    std::uint64_t imageHits = 0;
    std::uint64_t imageMisses = 0;
    std::uint64_t imageEvictions = 0;
    std::list<Slot*> imageOrder;
    std::uint64_t clock = 0;
    std::optional<std::chrono::steady_clock::time_point> idleRead;
    std::uint64_t idleClock = 0;
    std::uint64_t reclaimBefore = 0;
    std::uint64_t scannedIdleClock = 0;
    AgcDriver::Mutex slabMutex;
    std::unordered_map<std::uint64_t, Slab> slabs;
    std::unordered_map<VkDeviceMemory, std::unique_ptr<SlabBlock>> slabBlocks;
    AgcDriver::Mutex imageMutex;
    std::unordered_map<VkDeviceMemory, std::unique_ptr<ImageBlock>> imageBlocks;
    std::array<ImageBlock*, VK_MAX_MEMORY_TYPES> imageAvailable{};
    std::atomic<VkDeviceSize> retainedImageSlabBytes{0};
    static constexpr VkDeviceSize budget = 512ull * 1024 * 1024;
    // The small tier's own budget (slots of at most half a MiB each): pinned host memory the large
    // tier's budget does not count.
    static constexpr VkDeviceSize smallBudget = 64ull * 1024 * 1024;
    // Requests of this size and more keep their exact size and go to the large tier.
    static constexpr std::size_t classLimit = std::size_t{1} << 20u;
    static constexpr unsigned deviceClassBits = 3;
    static constexpr std::size_t defaultSlots = 4096;
    static constexpr std::size_t exactSizeScan = 64;
};

std::shared_ptr<BufferPool> GetBufferPool(const Context& context);
VkDeviceMemory AllocateImageMemory(const Context& context, const VkMemoryAllocateInfo& allocation, std::uint32_t mask, const char* operation, std::uint32_t* allocatedType = nullptr, bool newImage = false);
void ReleaseImageMemory(const Context& context, VkDeviceMemory memory, VkDeviceSize bytes, std::uint32_t memoryType) noexcept;

}

#endif
