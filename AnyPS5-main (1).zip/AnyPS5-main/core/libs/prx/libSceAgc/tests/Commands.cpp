#include "prx/libSceAgc/include/Agc.hpp"
#include "prx/libSceAgcDriver/Resource/include/Registration.hpp"
#include "prx/libSceAgc/Patch/include/WaitRegMem.hpp"
#include "prx/libSceAgc/Patch/include/IndirectRegisters.hpp"
#include "prx/libSceAgc/Patch/include/Nop.hpp"
#include "prx/libSceAgc/Patch/include/QueueEndOfPipeAction.hpp"
#include "prx/libSceAgc/Misc/include/Suspend.hpp"
#include "prx/libSceAgc/Misc/include/RegisterDefaults.hpp"
#include "prx/libSceAgc/Patch/include/Jump.hpp"
#include "prx/libSceAgc/Misc/include/PacketInfo.hpp"
#include "prx/libSceAgc/Misc/include/Debug.hpp"
#include "prx/libSceAgc/DcbState/include/Workload.hpp"
#include "prx/libSceAgc/DcbState/include/Marker.hpp"
#include "prx/libSceAgc/DcbState/include/Init.hpp"
#include "prx/libSceAgc/DcbState/include/Display.hpp"
#include "prx/libSceAgc/DcbState/include/ContextState.hpp"
#include "prx/libSceAgc/DcbFlow/include/Sync.hpp"
#include "prx/libSceAgc/DcbFlow/include/Memory.hpp"
#include "prx/libSceAgc/Acb/include/Memory.hpp"
#include "prx/libSceAgc/DcbFlow/include/Control.hpp"
#include "prx/libSceAgc/DcbDraw/include/Instancing.hpp"
#include "prx/libSceAgc/Acb/include/Dispatch.hpp"
#include "prx/libSceAgc/Cb/include/Dispatch.hpp"
#include "prx/libSceAgc/DcbFlow/include/Dispatch.hpp"
#include "prx/libSceAgc/DcbDraw/include/IndexBuffer.hpp"
#include "prx/libSceAgc/DcbDraw/include/DrawIndexed.hpp"
#include "prx/libSceAgc/DcbDraw/include/DrawNonIndexed.hpp"
#include "prx/libSceAgc/DcbDraw/include/Stats.hpp"
#include "prx/libSceAgc/Cb/include/Registers.hpp"
#include "prx/libSceAgc/Acb/include/Control.hpp"
#include "prx/libSceAgc/Acb/include/Sync.hpp"
#include "prx/libSceAgc/Command/include/Packet.hpp"
#include "prx/libSceAgc/Command/include/Memory.hpp"
#include "prx/libSceAgc/Acb/include/Memory.hpp"
#include "prx/libSceAgc/DcbFlow/include/Memory.hpp"
#include "prx/libSceAgc/Command/include/RegisterDefaults.hpp"
#include "prx/libc/include/Shutdown.hpp"

#include <algorithm>
#include <array>
#include <cstdio>
#include <stdexcept>
#include <cstring>
#include <string>

namespace {

void check(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

template <typename TAction>
void expectFailure(TAction action) {
    try {
        action();
    } catch (const std::runtime_error& error) {
        check(error.what()[0] != '\0', "empty exception message");
        return;
    }
    throw std::runtime_error("expected an exception");
}

struct Storage {
    std::array<std::uint32_t, 64> words{};
    CommandBuffer buffer{words.data(), words.data() + words.size(), words.data(), words.data() + words.size(), nullptr, nullptr, 0};
};

bool APS5_VABI grow(CommandBuffer* buffer, std::uint32_t count, void* userData) {
    auto& storage = *static_cast<Storage*>(userData);
    check(count == 5, "incorrect callback allocation including reserved words");
    buffer->bottom = storage.words.data();
    buffer->top = storage.words.data() + storage.words.size();
    buffer->cursor_up = buffer->bottom;
    buffer->cursor_down = buffer->top;
    return true;
}

bool APS5_VABI growReserved(CommandBuffer* buffer, std::uint32_t count, void* userData) {
    auto& storage = *static_cast<Storage*>(userData);
    check(count == 5 + 4, "incorrect callback allocation including reserved words");
    buffer->bottom = storage.words.data();
    buffer->top = storage.words.data() + storage.words.size();
    buffer->cursor_up = buffer->bottom;
    buffer->cursor_down = buffer->top;
    return true;
}

void testPackets() {
    Storage storage;
    sceAgcDcbResetQueue(&storage.buffer, 0, 3);
    sceAgcDcbDrawIndexAuto(&storage.buffer, 17, 0);
    const std::array<std::uint32_t, 5> expected{0xc0001200u, 3, 0xc0012d00u, 17, 2};
    check(std::equal(expected.begin(), expected.end(), storage.words.begin()), "reset or draw packet mismatch");
    check(storage.buffer.cursor_up == storage.words.data() + expected.size(), "incorrect packet cursor advance");
    const auto before = storage.words;
    expectFailure([&] { sceAgcDcbResetQueue(&storage.buffer, 0, 16); });
    check(storage.words == before, "invalid reset modified packet memory");
    Storage destination;
    CommandBuffer empty{nullptr, nullptr, nullptr, nullptr, grow, &destination, 0};
    Agc::Command::Emit(&empty, 0x15u, {1, 1, 1, 0x41u}, __func__);
    check(empty.cursor_up == destination.words.data() + 5, "guest ABI allocation callback failed");
    Storage reservedDestination;
    CommandBuffer reserved{nullptr, nullptr, nullptr, nullptr, growReserved, &reservedDestination, 4};
    Agc::Command::Emit(&reserved, 0x15u, {1, 1, 1, 0x41u}, __func__);
    check(reserved.cursor_up == reservedDestination.words.data() + 5, "buffer with less room than its reserved words did not grow");
    Storage exhausted;
    exhausted.buffer.cursor_down = exhausted.words.data() + 2;
    expectFailure([&] { Agc::Command::WriteNop(&exhausted.buffer, 3, __func__); });
    check(exhausted.buffer.cursor_up == exhausted.words.data(), "failed allocation advanced cursor");
    std::array<std::uint32_t, 8> scratch{};
    CommandBuffer noDown{scratch.data(), scratch.data() + scratch.size(), scratch.data(), nullptr, nullptr, nullptr, 0};
    Agc::Command::WriteNop(&noDown, 6, __func__);
    check(noDown.cursor_up == scratch.data() + 6, "buffer without a down cursor did not use its top as the limit");
    expectFailure([&] { Agc::Command::WriteNop(&noDown, 3, __func__); });
    check(noDown.cursor_up == scratch.data() + 6, "allocation past the top of a buffer without a down cursor advanced its cursor");
}

void testNop() {
    Storage storage;
    storage.words.fill(0xdeadbeefu);
    auto* single = sceAgcSetNop(&storage.buffer, 1);
    auto* pair = sceAgcSetNop(&storage.buffer, 2);
    auto* triple = sceAgcSetNop(&storage.buffer, 3);
    const std::array<std::uint32_t, 7> expected{0xffff1000u, 0xc0001000u, 0, 0xc0011000u, 0, 0, 0xdeadbeefu};
    check(single == storage.words.data() && pair == single + 1 && triple == pair + 2, "incorrect NOP placement");
    check(std::equal(expected.begin(), expected.end(), storage.words.begin()), "incorrect NOP packet");
    check(storage.buffer.cursor_up == storage.words.data() + 6, "incorrect NOP cursor advance");
    expectFailure([&] { sceAgcSetNop(&storage.buffer, 0); });
    expectFailure([&] { sceAgcSetNop(&storage.buffer, 0x4002u); });
    check(storage.buffer.cursor_up == storage.words.data() + 6, "invalid NOP advanced the cursor");
}

void testClearState() {
    Storage storage;
    storage.words.fill(0xdeadbeefu);
    for (std::uint32_t command = 0; command <= 0xfu; ++command) {
        auto* packet = sceAgcDcbClearState(&storage.buffer, command);
        check(packet == storage.words.data() + command * 2 && packet[0] == 0xc0001200u && packet[1] == command, "incorrect CLEAR_STATE packet");
    }
    auto* maskedZero = sceAgcDcbClearState(&storage.buffer, 0x10u);
    check(maskedZero == storage.words.data() + 32 && maskedZero[0] == 0xc0001200u && maskedZero[1] == 0, "CLEAR_STATE did not mask the command to four bits");
    auto* maskedF = sceAgcDcbClearState(&storage.buffer, 0xffffffffu);
    check(maskedF == storage.words.data() + 34 && maskedF[0] == 0xc0001200u && maskedF[1] == 0xfu, "CLEAR_STATE did not mask the command to four bits");
    check(storage.buffer.cursor_up == storage.words.data() + 36 && storage.words[36] == 0xdeadbeefu, "incorrect CLEAR_STATE cursor advance");
    const auto before = storage.words;
    expectFailure([] { sceAgcDcbClearState(nullptr, 0); });
    check(storage.words == before && storage.buffer.cursor_up == storage.words.data() + 36, "invalid CLEAR_STATE modified the buffer");
}

struct ContextGrowth {
    Storage destination;
    std::uint32_t* expectedCursor;
    std::uint32_t expectedCount;
    std::uint32_t calls = 0;
    bool success = true;
};

bool APS5_VABI growContext(CommandBuffer* buffer, std::uint32_t count, void* userData) {
    auto& growth = *static_cast<ContextGrowth*>(userData);
    check(++growth.calls == 1, "unexpected repeated context allocation callback");
    check(buffer->cursor_up == growth.expectedCursor, "context callback at wrong packet boundary");
    check(count == growth.expectedCount, "incorrect context reservation size");
    if (!growth.success) {
        return false;
    }
    buffer->bottom = growth.destination.buffer.bottom;
    buffer->top = growth.destination.buffer.top;
    buffer->cursor_up = growth.destination.buffer.cursor_up;
    buffer->cursor_down = growth.destination.buffer.cursor_down;
    return true;
}

void testIndexedIndirectDraws() {
    Storage storage;
    const auto* single = sceAgcDcbDrawIndexIndirect(&storage.buffer, 0x40, 0);
    const std::array<std::uint32_t, 5> expectedSingle{0xc0032500u, 0x40, 0x280, 0x280, 0};
    check(single == storage.words.data() && std::equal(expectedSingle.begin(), expectedSingle.end(), single), "indexed indirect draw packet mismatch");
    alignas(4) std::uint32_t count = 0;
    const auto* multi = sceAgcDcbDrawIndexIndirectMulti(&storage.buffer, 0x80, 1, 8, &count, 20, 0);
    const auto address = reinterpret_cast<std::uintptr_t>(&count);
    const std::array<std::uint32_t, 16> expectedMulti{0xc0017904u, 0x342, 0xc6000005u, 0xc0083800u, 0x80, 0x280, 0x280, 0x40000280u, 8, static_cast<std::uint32_t>(address), static_cast<std::uint32_t>(address >> 32u), 20, 0, 0xc0017904u, 0x342, 0xc6000000u};
    check(multi == storage.words.data() + expectedSingle.size() && std::equal(expectedMulti.begin(), expectedMulti.end(), multi), "indexed indirect multi draw packet mismatch");
    check(storage.buffer.cursor_up == storage.words.data() + expectedSingle.size() + expectedMulti.size(), "incorrect indexed indirect cursor advance");
    check(sceAgcDcbDrawIndexIndirectMultiGetSize() == expectedMulti.size() * sizeof(std::uint32_t), "indexed indirect multi draw size differs from its packets");
    const auto before = storage.words;
    expectFailure([&] { sceAgcDcbDrawIndexIndirect(&storage.buffer, 2, 0); });
    expectFailure([&] { sceAgcDcbDrawIndexIndirectMulti(&storage.buffer, 0, 1, 8, &count, 16, 0); });
    expectFailure([&] { sceAgcDcbDrawIndexIndirectMulti(&storage.buffer, 0, 0, 8, &count, 20, 0); });
    check(storage.words == before, "invalid indexed indirect draw modified packet memory");
}

void testTagHeaders() {
    Storage draw;
    const auto* multi = sceAgcDcbDrawIndirectMulti(&draw.buffer, 0x40, 0, 5, nullptr, 16, 0);
    const std::array<std::uint32_t, 16> expectedMulti{0xc0017904u, 0x342u, 0xc6000008u, 0xc0082c00u, 0x40u, 0x280u, 0x280u, 0x280u, 5u, 0u, 0u, 16u, 2u, 0xc0017904u, 0x342u, 0xc6000000u};
    check(multi == draw.words.data() && std::equal(expectedMulti.begin(), expectedMulti.end(), multi), "indirect multi draw tag words mismatch");
    alignas(8) std::uint64_t label = 0;
    const auto address = reinterpret_cast<std::uintptr_t>(&label);
    const auto low = static_cast<std::uint32_t>(address);
    const auto high = static_cast<std::uint32_t>(address >> 32u);
    for (const bool compute : {false, true}) {
        const auto tagFlags = compute ? 0u : 4u;
        const std::array<std::uint32_t, 14> expected32{0xc0027900u | tagFlags, 0x342u, 0xc8010000u | high, low, 0xc0053c00u, 0x13u, low, high, 1u, 0xffffffffu, 4u, 0xc0017900u | tagFlags, 0x342u, 0xc8000000u};
        const std::array<std::uint32_t, 16> expected64{0xc0027900u | tagFlags, 0x342u, 0xc8020000u | high, low, 0xc0079300u, 0x13u, low, high, 1u, 0u, 0xffffffffu, 0xffffffffu, 4u, 0xc0017900u | tagFlags, 0x342u, 0xc8000000u};
        Storage storage;
        auto* wait32 = compute ? sceAgcAcbWaitRegMem(&storage.buffer, 0, 3, 0, &label, 1, 0xffffffffu, 0x40) : sceAgcDcbWaitRegMem(&storage.buffer, 0, 3, 0, 0, &label, 1, 0xffffffffu, 0x40);
        auto* wait64 = compute ? sceAgcAcbWaitRegMem(&storage.buffer, 1, 3, 0, &label, 1, ~0ull, 0x40) : sceAgcDcbWaitRegMem(&storage.buffer, 1, 3, 0, 0, &label, 1, ~0ull, 0x40);
        check(wait32 == storage.words.data() && std::equal(expected32.begin(), expected32.end(), wait32), "32-bit wait tag words mismatch");
        check(wait64 == wait32 + expected32.size() && std::equal(expected64.begin(), expected64.end(), wait64), "64-bit wait tag words mismatch");
        check(sceAgcWaitRegMemPatchReference(wait32, 2) == 0 && wait32[8] == 2u, "wait reference patch refused the queue's tag headers");
        check(sceAgcWaitRegMemPatchReference(wait64, 3) == 0 && wait64[8] == 3u, "64-bit wait reference patch refused the queue's tag headers");
        for (const auto header : {0xc0027901u, 0xc0027902u}) {
            const auto start = wait32[0];
            wait32[0] = header;
            const auto before = storage.words;
            expectFailure([&] { sceAgcWaitRegMemPatchReference(wait32, 5); });
            check(storage.words == before, "a wait with another tag header was patched");
            wait32[0] = start;
        }
        wait32[11] ^= 4u;
        const auto before = storage.words;
        expectFailure([&] { sceAgcWaitRegMemPatchReference(wait32, 5); });
        check(storage.words == before, "a wait whose end tag header differs from its wrapper was patched");
    }
}

void testJumpTargetPatch() {
    const auto target = [](std::uintptr_t address) { return reinterpret_cast<const volatile std::uint32_t*>(address); };
    Storage storage;
    auto* packet = sceAgcDcbJump(&storage.buffer, 1, 2, reinterpret_cast<const std::uint32_t*>(0x1000ull), 0x40);
    check(sceAgcJumpPatchSetTarget_0300(packet, 1, target(0x123456789ab0u), 0x80) == 0, "jump target patch with a cache policy failed");
    check(packet[1] == 0x56789ab0u && packet[2] == 0x1234u && packet[3] == 0x1f300080u, "jump target patch did not replace the address, size and cache policy only");
    check(sceAgcJumpPatchSetTarget(packet, target(0x2000u), 0x10) == 0, "jump target patch failed");
    check(packet[1] == 0x2000u && packet[2] == 0 && packet[3] == 0x1f300010u, "jump target patch without a cache policy changed it");
    const auto before = storage.words;
    expectFailure([&] { sceAgcJumpPatchSetTarget_0300(packet, 4, target(0x3000u), 1); });
    expectFailure([&] { sceAgcJumpPatchSetTarget_0300(packet, 0, target(0x3002u), 1); });
    expectFailure([&] { sceAgcJumpPatchSetTarget(packet, target(0x3000u), 0x100000u); });
    packet[0] = Agc::Command::Header(0x3fu, 5);
    expectFailure([&] { sceAgcJumpPatchSetTarget(packet, target(0x3000u), 1); });
    packet[0] = before[0];
    check(storage.words == before, "a refused jump target patch modified the packet");
}

void testMarkers() {
    Storage dcb;
    Storage acb;
    const auto* dcbPush = sceAgcDcbPushMarker(&dcb.buffer, "frame", 0xff0000u);
    const auto* acbPush = sceAgcAcbPushMarker(&acb.buffer, "frame", 0x00ff00u);
    check(acbPush == acb.words.data() && acbPush[0] == Agc::Command::Header(0x10, 3, 0x0bu << 2u), "ACB push marker header mismatch");
    check(std::strcmp(reinterpret_cast<const char*>(acbPush + 1), "frame") == 0, "ACB push marker text mismatch");
    const auto* acbPop = sceAgcAcbPopMarker(&acb.buffer);
    check(acbPop == acb.words.data() + 3 && acbPop[0] == Agc::Command::Header(0x10, 2, 0x0cu << 2u) && acbPop[1] == 0, "ACB pop marker mismatch");
    sceAgcDcbPopMarker(&dcb.buffer);
    const auto* acbSet = sceAgcAcbSetMarker(&acb.buffer, nullptr, 0);
    const auto* dcbSet = sceAgcDcbSetMarker(&dcb.buffer, nullptr, 0);
    check(acbSet == acb.words.data() + 5 && dcbSet == dcb.words.data() + 5, "set marker did not return its push packet");
    check(acbSet[0] == Agc::Command::Header(0x10, 2, 0x0bu << 2u) && acbSet[1] == 0 && acbSet[2] == Agc::Command::Header(0x10, 2, 0x0cu << 2u), "ACB set marker is not a push and pop pair");
    check(dcbPush == dcb.words.data() && dcb.words == acb.words, "ACB and DCB markers differ");
    check(acb.buffer.cursor_up == acb.words.data() + 9, "incorrect ACB marker cursor advance");
    expectFailure([] { sceAgcAcbPushMarker(nullptr, "frame", 0); });
    expectFailure([] { sceAgcAcbPopMarker(nullptr); });
    expectFailure([] { sceAgcAcbSetMarker(nullptr, "frame", 0); });
}

void testMarkerSpans() {
    Storage dcb;
    Storage acb;
    const char text[] = "framebuffer";
    const auto* acbPush = sceAgcAcbPushMarkerSpan(&acb.buffer, text, 5, 0x00ff00u);
    const auto* dcbPush = sceAgcDcbPushMarkerSpan(&dcb.buffer, text, 5, 0xff0000u);
    check(acbPush == acb.words.data() && acbPush[0] == Agc::Command::Header(0x10, 3, 0x0bu << 2u), "ACB push marker span header mismatch");
    check(std::strcmp(reinterpret_cast<const char*>(acbPush + 1), "frame") == 0, "ACB push marker span does not stop at its length");
    check(dcbPush == dcb.words.data(), "DCB push marker span did not return its packet");
    const auto* acbSet = sceAgcAcbSetMarkerSpan(&acb.buffer, nullptr, 0, 0);
    const auto* dcbSet = sceAgcDcbSetMarkerSpan(&dcb.buffer, nullptr, 0, 0);
    check(acbSet == acb.words.data() + 3 && dcbSet == dcb.words.data() + 3, "set marker span did not return its push packet");
    check(acbSet[0] == Agc::Command::Header(0x10, 2, 0x0bu << 2u) && acbSet[1] == 0 && acbSet[2] == Agc::Command::Header(0x10, 2, 0x0cu << 2u), "ACB set marker span is not a push and pop pair");
    check(dcb.words == acb.words && acb.buffer.cursor_up == acb.words.data() + 7, "ACB and DCB marker spans differ");
    Storage plain;
    sceAgcAcbPushMarker(&plain.buffer, "frame", 0);
    check(std::equal(plain.words.begin(), plain.words.begin() + 3, acb.words.begin()), "marker span differs from the same text pushed whole");
    expectFailure([] { sceAgcAcbPushMarkerSpan(nullptr, "frame", 5, 0); });
    expectFailure([] { sceAgcAcbPushMarker(nullptr, reinterpret_cast<const char*>(std::uintptr_t{0x10}), 0); });
    expectFailure([] { sceAgcDcbSetMarkerSpan(nullptr, "frame", 5, 0); });
    expectFailure([&] { sceAgcDcbPushMarkerSpan(&dcb.buffer, nullptr, 4, 0); });
}

void testEndOfPipeAddressPatch() {
    const auto label = [](std::uintptr_t address) { return reinterpret_cast<const volatile Label*>(address); };
    std::array<std::uint32_t, 8> release{};
    release[0] = Agc::Command::Header(0x49u, 8);
    release[2] = 1u << 29u;
    check(sceAgcQueueEndOfPipeActionPatchAddress(release.data(), label(0x123456789abcu)) == 0 && release[3] == 0x56789abcu && release[4] == 0x1234u, "RELEASE_MEM address patch mismatch");
    release[2] = 2u << 29u;
    const auto before = release;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchAddress(release.data(), label(0x123456789ab4u)); });
    check(release == before, "a 64-bit RELEASE_MEM accepted a label that is not 8-byte aligned");
    check(sceAgcQueueEndOfPipeActionPatchAddress(release.data(), label(0x123456789ab8u)) == 0 && release[3] == 0x56789ab8u, "64-bit RELEASE_MEM address patch mismatch");
    std::array<std::uint32_t, 6> event{};
    event[0] = Agc::Command::Header(0x47u, 6);
    event[3] = (1u << 29u) | 0x00ab0000u;
    check(sceAgcQueueEndOfPipeActionPatchAddress(event.data(), label(0x123456789abcu)) == 0 && event[2] == 0x56789abcu && event[3] == ((1u << 29u) | 0x00ab1234u), "EVENT_WRITE_EOP address patch did not keep the control bits");
    const auto eventBefore = event;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchAddress(event.data(), label(0x1000000000000u)); });
    check(event == eventBefore, "an EVENT_WRITE_EOP accepted an address above 48 bits");
    event[0] = Agc::Command::Header(0x47u, 5);
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchAddress(event.data(), label(0x1000u)); });
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchAddress(nullptr, label(0x1000u)); });
}

void testWorkloads() {
    Storage dcb;
    const std::uint32_t ids[2] = {3, 4};
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, ids, 2) == nullptr, "workloads active packet for an unregistered stream");
    check(sceAgcDcbSetWorkloadComplete(&dcb.buffer, 1, 3) == nullptr, "workload complete packet for an unregistered stream");
    check(dcb.buffer.cursor_up == dcb.words.data(), "unregistered stream advanced the cursor");
    const std::uint32_t record[8] = {};
    check(sceAgcDriverRegisterWorkloadStream(1, record) == 0, "workload stream registration failed");
    const auto* active = sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, ids, 2);
    check(active == dcb.words.data() && active[0] == Agc::Command::Header(0x10, 18, 0) && active[1] == 1 && active[2] == 0x18 && active[3] == 0, "workloads active packet");
    for (std::uint32_t word = 4; word < 18; ++word) check(active[word] == 0, "workloads active packet tail is not zero");
    const auto* complete = sceAgcDcbSetWorkloadComplete(&dcb.buffer, 1, 33);
    check(complete == dcb.words.data() + 18 && complete[0] == Agc::Command::Header(0x10, 12, 0) && complete[1] == 1 && complete[2] == 33 && complete[3] == 0xffffffffu && complete[4] == 0xfffffffdu, "workload complete packet");
    for (std::uint32_t word = 5; word < 12; ++word) check(complete[word] == 0, "workload complete packet tail is not zero");
    const auto* inactive = sceAgcDcbSetWorkloadStreamInactive(&dcb.buffer, 1);
    check(inactive == dcb.words.data() + 30 && inactive[0] == Agc::Command::Header(0x10, 9, 0) && inactive[1] == 1, "workload stream inactive packet");
    for (std::uint32_t word = 2; word < 9; ++word) check(inactive[word] == 0, "workload stream inactive packet tail is not zero");
    check(dcb.buffer.cursor_up == dcb.words.data() + 39, "incorrect workload cursor advance");
    const std::uint32_t duplicate[2] = {5, 5};
    const std::uint32_t outOfRange[1] = {64};
    const std::uint32_t top[1] = {63};
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, duplicate, 2) == nullptr, "duplicate workload ids accepted");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, outOfRange, 1) == nullptr, "workload id 64 accepted");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, top, 1) != nullptr, "workload id 63 rejected");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, ids, 0) == nullptr, "workload count 0 accepted");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 1, nullptr, 2) == nullptr, "null workload ids accepted");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 0, ids, 2) == nullptr, "stream id 0 accepted");
    check(sceAgcDcbSetWorkloadsActive(&dcb.buffer, 32, ids, 2) == nullptr, "stream id 32 accepted");
    check(sceAgcDcbSetWorkloadComplete(&dcb.buffer, 1, 64) == nullptr, "workload complete id 64 accepted");
    check(sceAgcDcbSetWorkloadsActive(nullptr, 1, ids, 2) == nullptr, "null command buffer accepted");
    check(sceAgcDcbSetWorkloadComplete(nullptr, 1, 3) == nullptr, "null command buffer accepted for complete");
    check(sceAgcDriverUnregisterWorkloadStream(1) == 0, "workload stream unregistration failed");
    check(sceAgcDcbSetWorkloadComplete(&dcb.buffer, 1, 3) == nullptr, "workload complete packet after unregistration");
}

void testWorkloadStreams() {
    struct Vector {
        std::uint32_t streamId;
        std::uintptr_t workloadIds;
        std::uint32_t workloadCount;
        std::uint32_t workloadId;
    };
    const std::array<Vector, 3> vectors{{
        {0x11111111u, 0x22222222u, 0x33333333u, 0x22222222u},
        {1, 2, 3, 2},
        {0x22222222u, static_cast<std::uintptr_t>(0x3333333344444444ull), 0, 0x44444444u}}};
    for (const auto& vector : vectors) {
        Storage storage;
        storage.words.fill(0xdeadbeefu);
        const auto before = storage.words;
        const auto* ids = reinterpret_cast<const std::uint32_t*>(vector.workloadIds);
        check(sceAgcDcbSetWorkloadsActive(&storage.buffer, vector.streamId, ids, vector.workloadCount) == nullptr, "DCB workloads active returned a packet for an unregistered stream");
        check(sceAgcDcbSetWorkloadComplete(&storage.buffer, vector.streamId, vector.workloadId) == nullptr, "DCB workload complete returned a packet for an unregistered stream");
        check(sceAgcDcbSetWorkloadStreamInactive(&storage.buffer, vector.streamId) == nullptr, "DCB workload stream inactive returned a packet for an unregistered stream");
        check(sceAgcAcbSetWorkloadsActive(&storage.buffer, vector.streamId, ids, vector.workloadCount) == nullptr, "ACB workloads active returned a packet for an unregistered stream");
        check(sceAgcAcbSetWorkloadComplete(&storage.buffer, vector.streamId, vector.workloadId) == nullptr, "ACB workload complete returned a packet for an unregistered stream");
        check(sceAgcAcbSetWorkloadStreamInactive(&storage.buffer, vector.streamId) == nullptr, "ACB workload stream inactive returned a packet for an unregistered stream");
        check(storage.words == before && storage.buffer.cursor_up == storage.words.data(), "a workload call for an unregistered stream wrote to the buffer");
    }

    const std::uint32_t ids[2] = {3, 4};
    Storage exhausted;
    exhausted.buffer.cursor_down = exhausted.words.data() + 3;
    const auto before = exhausted.words;
    check(sceAgcDcbSetWorkloadStreamInactive(&exhausted.buffer, 1) == nullptr && sceAgcAcbSetWorkloadsActive(&exhausted.buffer, 1, ids, 2) == nullptr &&
        sceAgcAcbSetWorkloadComplete(&exhausted.buffer, 1, 3) == nullptr && sceAgcAcbSetWorkloadStreamInactive(&exhausted.buffer, 1) == nullptr,
        "a workload call for an unregistered stream on an exhausted buffer returned a packet");
    check(exhausted.words == before && exhausted.buffer.cursor_up == exhausted.words.data(), "a workload call for an unregistered stream modified an exhausted buffer");
    check(sceAgcDcbSetWorkloadStreamInactive(nullptr, 1) == nullptr && sceAgcAcbSetWorkloadsActive(nullptr, 1, ids, 2) == nullptr &&
        sceAgcAcbSetWorkloadComplete(nullptr, 1, 3) == nullptr && sceAgcAcbSetWorkloadStreamInactive(nullptr, 1) == nullptr,
        "a workload call with a null command buffer returned a packet");

    const std::uint32_t record[8] = {};
    check(sceAgcDriverRegisterWorkloadStream(1, record) == 0, "workload stream registration failed");
    Storage registered;
    registered.words.fill(0xdeadbeefu);
    const auto* acbActive = sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, ids, 2);
    check(acbActive == registered.words.data() && acbActive[0] == Agc::Command::Header(0x10, 18, 0) && acbActive[1] == 1 && acbActive[2] == 0x18 && acbActive[3] == 0, "ACB workloads active packet");
    for (std::uint32_t word = 4; word < 18; ++word) check(acbActive[word] == 0, "ACB workloads active packet tail is not zero");
    const auto* acbComplete = sceAgcAcbSetWorkloadComplete(&registered.buffer, 1, 33);
    check(acbComplete == registered.words.data() + 18 && acbComplete[0] == Agc::Command::Header(0x10, 12, 0) && acbComplete[1] == 1 && acbComplete[2] == 33 && acbComplete[3] == 0xffffffffu && acbComplete[4] == 0xfffffffdu, "ACB workload complete packet");
    for (std::uint32_t word = 5; word < 12; ++word) check(acbComplete[word] == 0, "ACB workload complete packet tail is not zero");
    const auto* acbInactive = sceAgcAcbSetWorkloadStreamInactive(&registered.buffer, 1);
    check(acbInactive == registered.words.data() + 30 && acbInactive[0] == Agc::Command::Header(0x10, 9, 0) && acbInactive[1] == 1, "ACB workload stream inactive packet");
    for (std::uint32_t word = 2; word < 9; ++word) check(acbInactive[word] == 0, "ACB workload stream inactive packet tail is not zero");
    check(registered.buffer.cursor_up == registered.words.data() + 39, "incorrect ACB workload cursor advance");
    const std::uint32_t duplicate[2] = {5, 5};
    const std::uint32_t outOfRange[1] = {64};
    const std::uint32_t top[1] = {63};
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, duplicate, 2) == nullptr, "ACB duplicate workload ids accepted");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, outOfRange, 1) == nullptr, "ACB workload id 64 accepted");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, top, 1) != nullptr, "ACB workload id 63 rejected");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, ids, 0) == nullptr, "ACB workload count 0 accepted");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 1, nullptr, 2) == nullptr, "ACB null workload ids accepted");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 0, ids, 2) == nullptr, "ACB stream id 0 accepted");
    check(sceAgcAcbSetWorkloadsActive(&registered.buffer, 32, ids, 2) == nullptr, "ACB stream id 32 accepted");
    check(sceAgcAcbSetWorkloadComplete(&registered.buffer, 1, 64) == nullptr, "ACB workload complete id 64 accepted");
    check(sceAgcAcbSetWorkloadsActive(nullptr, 1, ids, 2) == nullptr, "ACB null command buffer accepted for active");
    check(sceAgcDcbSetWorkloadStreamInactive(nullptr, 1) == nullptr && sceAgcAcbSetWorkloadsActive(nullptr, 1, ids, 2) == nullptr &&
        sceAgcAcbSetWorkloadComplete(nullptr, 1, 3) == nullptr && sceAgcAcbSetWorkloadStreamInactive(nullptr, 1) == nullptr,
        "a workload call with a null command buffer for a registered stream returned a packet");
    check(sceAgcDriverUnregisterWorkloadStream(1) == 0, "workload stream unregistration failed");
    check(sceAgcAcbSetWorkloadComplete(&registered.buffer, 1, 3) == nullptr, "ACB workload complete packet after unregistration");
}

void testDrawPackets() {
    Storage indirect;
    const auto* draw = sceAgcDcbDrawIndirect(&indirect.buffer, 0x40, 0);
    const std::array<std::uint32_t, 5> indirectExpected{0xc0032400u, 0x40, 0x280, 0x280, 2};
    check(draw == indirect.words.data() && std::equal(indirectExpected.begin(), indirectExpected.end(), indirect.words.begin()), "DRAW_INDIRECT packet mismatch");
    Storage flagged;
    sceAgcDcbDrawIndirect(&flagged.buffer, 0, 0x100);
    sceAgcDcbDrawIndirect(&flagged.buffer, 0, 0x100000100ull);
    check(flagged.words[4] == 0x22u && flagged.words[9] == 2, "DRAW_INDIRECT initiator flags mismatch");
    Storage offset;
    sceAgcDcbDrawIndexOffset(&offset.buffer, 16, 0, 0);
    sceAgcDcbDrawIndexOffset(&offset.buffer, 16, 9, 0);
    const std::array<std::uint32_t, 10> offsetExpected{0xc0033500u, 1, 16, 0, 0, 0xc0033500u, 9, 16, 9, 0};
    check(std::equal(offsetExpected.begin(), offsetExpected.end(), offset.words.begin()), "DRAW_INDEX_OFFSET_2 packet mismatch");
    Storage instances;
    sceAgcDcbSetNumInstances(&instances.buffer, 3);
    check(instances.words[0] == 0xc0002f00u && instances.words[1] == 3, "NUM_INSTANCES packet mismatch");
    Storage size;
    sceAgcDcbSetIndexSize(&size.buffer, 1, 2);
    sceAgcDcbSetIndexSize_0600(&size.buffer, 2, 3, 1);
    const std::array<std::uint32_t, 6> sizeExpected{0xc0017a00u, 0x20000243u, 0x481u, 0xc0017a00u, 0x20000243u, 0x44c2u};
    check(std::equal(sizeExpected.begin(), sizeExpected.end(), size.words.begin()), "index size packet mismatch");
    Storage rejected;
    rejected.words.fill(0xa5a5a5a5u);
    const auto rejectedWords = rejected.words;
    const auto* rejectedCursor = rejected.buffer.cursor_up;
    expectFailure([&] { sceAgcDcbDrawIndirect(&rejected.buffer, 2, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbDrawIndirect(&rejected.buffer, 0, 0x200000000ull); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbSetIndexSize(&rejected.buffer, 3, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbSetIndexSize(&rejected.buffer, 0, 4); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbSetIndexSize_0600(&rejected.buffer, 0, 0, 2); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    check(sceAgcDcbDrawIndirectGetSize() == 20 && sceAgcDcbDrawIndexOffsetGetSize() == 20 && sceAgcDcbSetNumInstancesGetSize() == 8 && sceAgcDcbSetIndexSizeGetSize() == 12, "draw packet sizes");
}

void testIndexBuffer() {
    Storage storage;
    alignas(4) std::uint16_t indices[2]{};
    const auto address = reinterpret_cast<std::uintptr_t>(indices);
    const auto* bound = sceAgcDcbSetIndexBuffer(&storage.buffer, address);
    check(bound[1] == static_cast<std::uint32_t>(address) && bound[2] == static_cast<std::uint32_t>(address >> 32u), "index buffer address mismatch");
    const auto* unbound = sceAgcDcbSetIndexBuffer(&storage.buffer, 0);
    check(unbound == bound + 3 && unbound[0] == bound[0] && unbound[1] == 0 && unbound[2] == 0, "index buffer was not unbound");
    const auto before = storage.words;
    try {
        sceAgcDcbSetIndexBuffer(&storage.buffer, 0x1001);
    } catch (const std::runtime_error& error) {
        check(std::string(error.what()).find("0x1001") != std::string::npos, "misaligned index buffer error omits the address");
        check(storage.words == before, "misaligned index buffer modified packet memory");
        return;
    }
    throw std::runtime_error("misaligned index buffer was accepted");
}

void testIndexIndirectArgs() {
    Storage storage;
    const auto* packet = sceAgcDcbSetIndexIndirectArgs(&storage.buffer, 0x1111111122222220u, 0x4444u);
    const std::array<std::uint32_t, 4> expected{0xc0029100u, 0x22222220u, 0x11111111u, 0x4444u};
    check(packet == storage.words.data() && std::equal(expected.begin(), expected.end(), packet), "index indirect args packet differs from the console's");
    check(sceAgcDcbSetIndexIndirectArgsGetSize() == expected.size() * sizeof(std::uint32_t), "index indirect args size differs from its packet");
    const auto* cleared = sceAgcDcbSetIndexIndirectArgs(&storage.buffer, 0, 0);
    check(cleared == packet + expected.size() && cleared[0] == expected[0] && cleared[1] == 0 && cleared[2] == 0 && cleared[3] == 0, "null index attribute base was not written as 0");
    const auto before = storage.words;
    expectFailure([&] { sceAgcDcbSetIndexIndirectArgs(&storage.buffer, 0x1111111122222228u, 0); });
    expectFailure([&] { sceAgcDcbSetIndexIndirectArgs(&storage.buffer, 0x1111111122222220u, 0x10000u); });
    check(storage.words == before && storage.buffer.cursor_up == cleared + expected.size(), "rejected index indirect args modified the buffer");
}

void testIndirectBase() {
    Storage storage;
    alignas(8) std::uint32_t arguments[4]{};
    const auto address = reinterpret_cast<std::uintptr_t>(arguments);
    const auto* bound = sceAgcDcbSetBaseIndirectArgs(&storage.buffer, 0, arguments);
    check(bound[1] == 1 && bound[2] == static_cast<std::uint32_t>(address) && bound[3] == static_cast<std::uint32_t>(address >> 32u), "indirect base address mismatch");
    const auto* cleared = sceAgcDcbSetBaseIndirectArgs(&storage.buffer, 1, nullptr);
    check(cleared == bound + 4 && (cleared[0] & 2u) != 0 && cleared[1] == 1 && cleared[2] == 0 && cleared[3] == 0, "indirect base was not cleared");
    const auto before = storage.words;
    expectFailure([&] { sceAgcDcbSetBaseIndirectArgs(&storage.buffer, 0, reinterpret_cast<const volatile void*>(address + 4)); });
    check(storage.words == before, "misaligned indirect base modified packet memory");
}

void testContextState() {
    const std::array<std::array<std::uint32_t, 6>, 4> sizes{{{5}, {5, 8, 9, 3, 2}, {3, 5, 8, 9, 2}, {5, 8, 9, 3, 2, 5}}};
    const std::array<std::array<std::uint32_t, 4>, 4> reservations{{{5}, {22, 3, 2}, {3, 22, 2}, {22, 3, 2, 5}}};
    const std::array<std::uint32_t, 4> totals{5, 27, 27, 32};
    for (std::uint32_t operation = 0; operation < sizes.size(); ++operation) {
        for (std::uint32_t capacity = 0; capacity <= totals[operation]; ++capacity) {
            Storage source;
            source.words.fill(0xdeadbeefu);
            std::uint32_t split = 0;
            std::uint32_t requested = 0;
            for (const auto count : reservations[operation]) {
                if (count > capacity - split) {
                    requested = count;
                    break;
                }
                split += count;
            }
            ContextGrowth growth{{}, source.words.data() + split, requested + 2};
            growth.destination.words.fill(0xdeadbeefu);
            source.buffer.cursor_down = source.words.data() + capacity + 2;
            source.buffer.reserved_dw = 2;
            source.buffer.callback = growContext;
            source.buffer.user_data = &growth;
            auto* first = sceAgcDcbContextStateOp_0100(&source.buffer, operation);
            check(first == (split == 0 ? growth.destination.words.data() : source.words.data()), "incorrect first context packet address");
            check(growth.calls == (requested == 0 ? 0u : 1u), "incorrect context callback count");
            auto* end = requested == 0 ? source.words.data() + totals[operation] : growth.destination.words.data() + totals[operation] - split;
            check(source.buffer.cursor_up == end, "incorrect context cursor advance");
            check(*end == 0xdeadbeefu && source.words[split] == 0xdeadbeefu, "context allocation overwrote adjacent memory");
            std::uint32_t offset = 0;
            for (const auto count : sizes[operation]) {
                if (count == 0) {
                    break;
                }
                const auto* packet = offset < split ? source.words.data() + offset : growth.destination.words.data() + offset - split;
                const auto header = 0xc0001000u | ((count - 2u) << 16u) | (offset == 0 ? 0x68u : 0u);
                check(packet[0] == header, "incorrect context packet header");
                for (std::uint32_t i = 1; i < count; ++i) {
                    check(packet[i] == (offset == 0 && i == 1 ? operation : 0u), "incorrect context packet payload");
                }
                offset += count;
            }
        }
    }
    expectFailure([] { sceAgcDcbContextStateOp_0100(nullptr, 0); });
    Storage invalid;
    expectFailure([&] { sceAgcDcbContextStateOp_0100(&invalid.buffer, 4); });
    check(invalid.buffer.cursor_up == invalid.words.data(), "invalid context operation advanced cursor");
    invalid.buffer.cursor_up = invalid.words.data() + 1;
    invalid.buffer.cursor_down = invalid.words.data();
    expectFailure([&] { sceAgcDcbContextStateOp_0100(&invalid.buffer, 0); });
    invalid.buffer.cursor_up = invalid.words.data();
    expectFailure([&] { sceAgcDcbContextStateOp_0100(&invalid.buffer, 1); });
    ContextGrowth growth{{}, invalid.words.data(), 22};
    invalid.buffer.callback = growContext;
    invalid.buffer.user_data = &growth;
    growth.success = false;
    expectFailure([&] { sceAgcDcbContextStateOp_0100(&invalid.buffer, 1); });
    growth.calls = 0;
    growth.success = true;
    growth.destination.buffer.cursor_down = growth.destination.words.data() + 21;
    expectFailure([&] { sceAgcDcbContextStateOp_0100(&invalid.buffer, 1); });
    check(invalid.buffer.cursor_up == growth.destination.words.data(), "failed reservation advanced cursor");
}

void testFlowPackets() {
    const auto* target = reinterpret_cast<const std::uint32_t*>(0x123456789ab0ull);
    Storage chained;
    const auto* jump = sceAgcDcbJump(&chained.buffer, 1, 2, target, 0x40);
    const std::array<std::uint32_t, 4> chainedExpected{0xc0023f00u, 0x56789ab0u, 0x1234u, 0x2f300040u};
    check(jump == chained.words.data() && std::equal(chainedExpected.begin(), chainedExpected.end(), chained.words.begin()), "chained INDIRECT_BUFFER packet mismatch");
    Storage called;
    sceAgcDcbJump(&called.buffer, 0, 0, target, 0xfffffu);
    check(called.words[3] == 0x0f2fffffu, "unchained INDIRECT_BUFFER control word mismatch");
    Storage compute;
    sceAgcAcbJump(&compute.buffer, 1, target, 0x10);
    check(compute.words[0] == 0xc0023f00u && compute.words[3] == 0x1f300010u, "compute jumps did not chain");
    Storage rejected;
    rejected.words.fill(0xa5a5a5a5u);
    const auto rejectedWords = rejected.words;
    const auto* rejectedCursor = rejected.buffer.cursor_up;
    expectFailure([&] { sceAgcDcbJump(&rejected.buffer, 2, 0, target, 1); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbJump(&rejected.buffer, 0, 4, target, 1); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbJump(&rejected.buffer, 0, 0, target, 0x100000u); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcAcbJump(&rejected.buffer, 0, reinterpret_cast<const std::uint32_t*>(0x1002ull), 1); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    check(sceAgcDcbJumpGetSize() == 16 && sceAgcAcbJumpGetSize() == 16, "jump packet sizes");
    Storage stall;
    sceAgcDcbStallCommandBufferParser(&stall.buffer);
    check(stall.words[0] == 0xc0004200u && stall.words[1] == 0 && sceAgcDcbStallCommandBufferParserGetSize() == 8, "PFP_SYNC_ME packet mismatch");
    Storage rendering;
    sceAgcDcbWaitUntilSafeForRendering(&rendering.buffer, 7, 2);
    const std::array<std::uint32_t, 4> renderingExpected{0xc0021018u, 7, 2, 0};
    check(std::equal(renderingExpected.begin(), renderingExpected.end(), rendering.words.begin()), "rendering wait packet mismatch");
    Storage reset;
    sceAgcAcbResetQueue(&reset.buffer, 5, 9);
    check(reset.words[0] == 0xc0001024u && reset.words[1] == 5 && reset.words[2] == 0, "compute queue reset packet mismatch");
    expectFailure([&] { sceAgcAcbResetQueue(nullptr, 5, 9); });
}

void testFlip() {
    Storage storage;
    storage.words.fill(0xdeadbeefu);
    auto* packet = sceAgcDcbSetFlip(&storage.buffer, 0xfedcba98u, -2, 0x12345678u, -0x123456789abcdefLL);
    const std::array<std::uint32_t, 6> expected{0xc004105cu, 0xfedcba98u, 0xfffffffeu, 0x12345678u, 0x76543211u, 0xfedcba98u};
    check(packet == storage.words.data(), "flip returned wrong packet address");
    check(std::equal(expected.begin(), expected.end(), packet), "flip packet lost argument bits");
    check(storage.buffer.cursor_up == packet + 6 && packet[6] == 0xdeadbeefu, "flip packet overran allocation");
    expectFailure([] { sceAgcDcbSetFlip(nullptr, 1, 0, 1, 0); });
    Storage exhausted;
    exhausted.buffer.cursor_down = exhausted.words.data() + 5;
    expectFailure([&] { sceAgcDcbSetFlip(&exhausted.buffer, 1, 0, 1, 0); });
    check(exhausted.buffer.cursor_up == exhausted.words.data(), "failed flip allocation advanced cursor");
    Storage acb;
    acb.words.fill(0xdeadbeefu);
    auto* wait = sceAgcAcbWaitUntilSafeForRendering(&acb.buffer, 0xfedcba98u, 2);
    const std::array<std::uint32_t, 4> expectedWait{0xc0021018u, 0xfedcba98u, 2, 0};
    check(wait == acb.words.data() && std::equal(expectedWait.begin(), expectedWait.end(), wait), "compute rendering wait packet mismatch");
    check(acb.buffer.cursor_up == wait + 4 && wait[4] == 0xdeadbeefu, "compute rendering wait overran allocation");
    expectFailure([] { sceAgcAcbWaitUntilSafeForRendering(nullptr, 1, 0); });
    Storage full;
    full.buffer.cursor_down = full.words.data() + 3;
    expectFailure([&] { sceAgcAcbWaitUntilSafeForRendering(&full.buffer, 1, 0); });
    check(full.buffer.cursor_up == full.words.data(), "failed compute rendering wait advanced cursor");
    Storage acbFlip;
    acbFlip.words.fill(0xdeadbeefu);
    auto* computeFlip = sceAgcAcbSetFlip(&acbFlip.buffer, 0xfedcba98u, -2, 0x12345678u, -0x123456789abcdefLL);
    check(computeFlip == acbFlip.words.data() && std::equal(expected.begin(), expected.end(), computeFlip), "compute flip packet mismatch");
    check(acbFlip.buffer.cursor_up == computeFlip + 6 && computeFlip[6] == 0xdeadbeefu, "compute flip overran allocation");
    expectFailure([] { sceAgcAcbSetFlip(nullptr, 1, 0, 1, 0); });
    Storage fullFlip;
    fullFlip.buffer.cursor_down = fullFlip.words.data() + 5;
    expectFailure([&] { sceAgcAcbSetFlip(&fullFlip.buffer, 1, 0, 1, 0); });
    check(fullFlip.buffer.cursor_up == fullFlip.words.data(), "failed compute flip advanced cursor");
    check(sceAgcSuspendPoint() == 0, "empty suspend failed");
}

void testRegisters() {
    Storage storage;
    const std::array<ShaderRegister, 3> registers{{{0x10, 7}, {0x11, 8}, {0x20, 9}}};
    Agc::Command::WriteRegisters(&storage.buffer, 0x76u, registers.data(), registers.size(), true, __func__);
    const std::array<std::uint32_t, 7> expected{0xc0027600u, 0x10, 7, 8, 0xc0017600u, 0x20, 9};
    check(std::equal(expected.begin(), expected.end(), storage.words.begin()), "register run packet mismatch");
    auto* packet = Agc::Command::WriteIndirectRegisters(&storage.buffer, 0x63u, registers.data(), 0x3ffeu, __func__);
    Agc::Command::PatchIndirectCount(packet, 0x63u, 1, __func__);
    check(packet[4] == 0x3fffu, "indirect register count mismatch");
    const auto before = storage.words;
    expectFailure([&] { Agc::Command::PatchIndirectCount(packet, 0x63u, 1, __func__); });
    expectFailure([&] { Agc::Command::PatchIndirectAddress(packet, 0x64u, registers.data(), __func__); });
    check(storage.words == before, "invalid indirect patch modified memory");
}

void testIndirectRegisterPatches() {
    using AddRegisters = int (APS5_VABI *)(std::uint32_t*, std::uint32_t);
    const std::array<ShaderRegister, 2> registers{{{0x10, 7}, {0x11, 8}}};
    const std::array<std::pair<std::uint32_t, AddRegisters>, 3> kinds{{{0x9fu, sceAgcSetCxRegIndirectPatchAddRegisters}, {0x63u, sceAgcSetShRegIndirectPatchAddRegisters}, {0x64u, sceAgcSetUcRegIndirectPatchAddRegisters}}};
    for (std::size_t i = 0; i < kinds.size(); ++i) {
        Storage storage;
        auto* packet = Agc::Command::WriteIndirectRegisters(&storage.buffer, kinds[i].first, registers.data(), 2, __func__);
        check(kinds[i].second(packet, 3) == 0 && packet[4] == 5, "indirect register patch did not add to the count");
        check(kinds[i].second(packet, 0x3fffu - 5u) == 0 && packet[4] == 0x3fffu, "indirect register patch did not reach the largest count");
        const auto before = storage.words;
        expectFailure([&] { kinds[i].second(packet, 1); });
        check(storage.words == before, "an overflowing indirect register patch modified the packet");
        expectFailure([&] { kinds[(i + 1) % kinds.size()].second(packet, 1); });
        check(storage.words == before, "an indirect register patch of another packet kind modified the packet");
    }
}

void testRegisterRange() {
    Storage storage;
    storage.words.fill(0xdeadbeefu);
    auto* packet = sceAgcCbSetShRegisterRangeDirect(&storage.buffer, 0x8c, nullptr, 4);
    auto expected = storage.words;
    expected.fill(0xdeadbeefu);
    expected[0] = 0xc0047600u;
    expected[1] = 0x8c;
    check(packet == storage.words.data(), "incorrect register range packet address");
    check(storage.buffer.cursor_up == storage.words.data() + 6, "incorrect register range allocation");
    check(storage.words == expected, "null register values modified payload or adjacent memory");
    const std::array<std::uint32_t, 4> values{1, 2, 3, 4};
    packet = sceAgcCbSetShRegisterRangeDirect(&storage.buffer, 0x90, values.data(), values.size());
    expected[6] = 0xc0047600u;
    expected[7] = 0x90;
    std::copy(values.begin(), values.end(), expected.begin() + 8);
    check(packet == storage.words.data() + 6 && storage.buffer.cursor_up == storage.words.data() + 12, "incorrect populated register range allocation");
    check(storage.words == expected, "register values were not copied correctly");
    const auto* misaligned = reinterpret_cast<const std::uint32_t*>(reinterpret_cast<const unsigned char*>(values.data()) + 1);
    packet = sceAgcCbSetShRegisterRangeDirect(&storage.buffer, 0x8c, misaligned, 3);
    expected[12] = 0xc0037600u;
    expected[13] = 0x8c;
    expected[14] = 0x02000000u;
    expected[15] = 0x03000000u;
    expected[16] = 0x04000000u;
    check(packet == storage.words.data() + 12 && storage.buffer.cursor_up == storage.words.data() + 17, "incorrect misaligned register range allocation");
    check(storage.words == expected, "misaligned register values were not read byte for byte");
}

void testPacketPayloadAddress() {
    Storage storage;
    auto* packet = sceAgcCbSetShRegisterRangeDirect(&storage.buffer, 0x8c, nullptr, 4);
    std::uint32_t* payload = nullptr;
    check(sceAgcGetDataPacketPayloadAddress_0090(&payload, packet, 1) == 0 && payload == packet + 2, "incorrect register packet payload address");
    const std::array<std::uint32_t, 4> values{11, 22, 33, 44};
    std::copy(values.begin(), values.end(), payload);
    const std::array<std::uint32_t, 6> expected{0xc0047600u, 0x8c, 11, 22, 33, 44};
    check(std::equal(expected.begin(), expected.end(), packet), "payload write corrupted register packet");
    check(sceAgcGetDataPacketPayloadAddress_0090(&payload, packet, 0) == 0 && payload == packet + 1, "incorrect generic packet payload address");
    packet[0] = 0xffff1000u;
    check(sceAgcGetDataPacketPayloadAddress_0090(&payload, packet, 0) == 0 && payload == nullptr, "empty payload marker was not recognized");
    check(sceAgcGetDataPacketPayloadAddress_0090(&payload, packet, -1) == 0 && payload == packet + 2, "nonzero payload type did not skip two words");
    expectFailure([&] { sceAgcGetDataPacketPayloadAddress_0090(nullptr, packet, 1); });
    expectFailure([&] { sceAgcGetDataPacketPayloadAddress_0090(&payload, nullptr, 1); });
    auto* misaligned = reinterpret_cast<std::uint32_t*>(reinterpret_cast<unsigned char*>(packet) + 1);
    expectFailure([&] { sceAgcGetDataPacketPayloadAddress_0090(&payload, misaligned, 0); });
    check(payload == packet + 2, "invalid packet changed output address");
}

void testMemory() {
    Storage storage;
    Agc::Command::WriteDma(&storage.buffer, false, 1, 0, 0, 0x2000, 2, 0, 0x12345678, 16, 0, 1, 1, __func__);
    const std::array<std::uint32_t, 7> expected{0xc0055000u, 0xc0000001u, 0x12345678, 0, 0x2000, 0, 0x80000010u};
    check(std::equal(expected.begin(), expected.end(), storage.words.begin()), "DMA packet mismatch");
    std::uint64_t value = 0;
    auto* packet = Agc::Command::WriteWait(&storage.buffer, false, 1, 3, 0, 0, &value, 0x1122334455667788ull, 0xffffffffffffffffull, 32, __func__);
    check(packet[0] == 0xc0027904u && packet[4] == 0xc0079300u && packet[5] == 0x13u, "wait packet header mismatch");
    check(packet[8] == 0x55667788u && packet[9] == 0x11223344u && packet[12] == 2u, "wait reference or poll interval mismatch");
    sceAgcWaitRegMemPatchReference(packet, 7);
    check(packet[8] == 7 && packet[9] == 0x11223344u, "reference patch changed the high word");
    auto* truncated = Agc::Command::WriteWait(&storage.buffer, false, 0, 3, 0, 0, &value, 0x100000000ull, 0xffffffff00000001ull, 32, __func__);
    check(truncated[8] == 0u && truncated[9] == 1u, "32-bit wait did not keep the low halves of the reference and mask");
    sceAgcWaitRegMemPatchMask(packet, 0x0f0f0f0fu);
    check(packet[10] == 0x0f0f0f0fu && packet[11] == 0xffffffffu && packet[8] == 7, "64-bit mask patch changed the wrong word");
    sceAgcWaitRegMemPatchMask(truncated, 0xff00u);
    check(truncated[9] == 0xff00u && truncated[8] == 0u && truncated[10] == 2u, "32-bit mask patch changed the wrong word");
    for (auto* waitPacket : {packet, truncated}) {
        const auto lowMask = waitPacket == packet ? 7u : 3u;
        waitPacket[6] |= lowMask;
        waitPacket[7] = 0xa5fc0000u;
        const auto tag = waitPacket[2] & 0xffff0000u;
        const std::uintptr_t address = 0x123456789ab8ull;
        check(sceAgcWaitRegMemPatchAddress(waitPacket, reinterpret_cast<const volatile void*>(address)) == 0, "wait address patch failed");
        check(waitPacket[2] == (tag | 0x1234u) && waitPacket[3] == 0x56789ab8u, "wait wrapper address patch mismatch");
        check(waitPacket[6] == ((0x56789ab8u & ~lowMask) | lowMask) && waitPacket[7] == 0xa5fc1234u, "wait address patch did not preserve control bits");
        for (std::uint32_t comparison = 0; comparison <= 6; ++comparison) {
            const auto control = waitPacket[5] & ~7u;
            check(sceAgcWaitRegMemPatchCompareFunction(waitPacket, static_cast<std::uint8_t>(comparison)) == 0, "wait comparison patch failed");
            check(waitPacket[5] == (control | comparison), "wait comparison patch changed control bits");
        }
        const auto beforeComparison = storage.words;
        for (std::uint32_t comparison = 7; comparison <= 255; ++comparison) {
            expectFailure([&] { sceAgcWaitRegMemPatchCompareFunction(waitPacket, static_cast<std::uint8_t>(comparison)); });
        }
        check(storage.words == beforeComparison, "a rejected wait comparison patch modified packet memory");
    }
    const auto beforeAddress = storage.words;
    expectFailure([&] { sceAgcWaitRegMemPatchAddress(packet, reinterpret_cast<const volatile void*>(std::uintptr_t{0x123456789ab4u})); });
    expectFailure([&] { sceAgcWaitRegMemPatchAddress(truncated, reinterpret_cast<const volatile void*>(std::uintptr_t{0x123456789ab2u})); });
    check(storage.words == beforeAddress, "a misaligned wait address patch modified packet memory");
    check(sceAgcWaitRegMemPatchAddress(truncated, reinterpret_cast<const volatile void*>(std::uintptr_t{0x123456789ab4u})) == 0 && truncated[3] == 0x56789ab4u, "32-bit wait rejected a 4-byte aligned address");
    const auto beforeWideAddress = storage.words;
    expectFailure([&] { sceAgcWaitRegMemPatchAddress(packet, reinterpret_cast<const volatile void*>(std::uintptr_t{0x1000000000008u})); });
    expectFailure([&] { sceAgcWaitRegMemPatchAddress(truncated, reinterpret_cast<const volatile void*>(std::uintptr_t{0x1000000000004u})); });
    check(storage.words == beforeWideAddress, "a wait address above 48 bits modified packet memory");
    const auto beforeMask = storage.words;
    expectFailure([&] { sceAgcWaitRegMemPatchMask(packet + 4, 1); });
    check(storage.words == beforeMask, "invalid mask patch modified packet memory");

    Storage acquireStorage;
    auto* acquire = sceAgcDcbAcquireMem(&acquireStorage.buffer, 0, 0x1234u, 0x567u, nullptr, 0x1000, 0);
    check(acquire[0] == Agc::Command::Header(0x58u, 8), "acquire mem header mismatch");
    check(acquire[1] == 0x1234u, "acquire mem engine bit was set");
    check(sceAgcAcquireMemSetEngine(acquire, 1) == 0, "sceAgcAcquireMemSetEngine failed");
    check(acquire[1] == 0x80001234u, "acquire mem engine bit was not set to 1");
    check(sceAgcAcquireMemSetEngine(acquire, 0) == 0, "sceAgcAcquireMemSetEngine failed");
    check(acquire[1] == 0x1234u, "acquire mem engine bit was not cleared to 0");
    check(sceAgcAcquireMemSetEngine(acquire, 1) == 0, "sceAgcAcquireMemSetEngine failed");
    check(acquire[1] == 0x80001234u, "acquire mem engine bit was not set to 1");
    check(sceAgcAcquireMemSetEngine(acquire, 2) == 0, "sceAgcAcquireMemSetEngine failed with engine 2");
    check(acquire[1] == 0x1234u, "engine 2 did not clear the engine bit");
    check(sceAgcAcquireMemSetEngine(acquire, 3) == 0, "sceAgcAcquireMemSetEngine failed with engine 3");
    check(acquire[1] == 0x80001234u, "engine 3 did not set the engine bit");
    check(sceAgcAcquireMemSetEngine(acquire, 4) == 0, "sceAgcAcquireMemSetEngine failed with engine 4");
    check(acquire[1] == 0x1234u, "engine 4 did not clear the engine bit");
    check(sceAgcAcquireMemSetEngine(acquire, static_cast<std::uint8_t>(0xffffffffu)) == 0, "sceAgcAcquireMemSetEngine failed with 0xffffffff");
    check(acquire[1] == 0x80001234u, "0xffffffff did not set the engine bit");
    check(sceAgcAcquireMemSetEngine(acquire, 0) == 0, "sceAgcAcquireMemSetEngine failed");
    check(acquire[1] == 0x1234u, "acquire mem engine bit was not cleared to 0");
    check(sceAgcAcquireMemSetEngine(acquire, 0xffu) == 0, "sceAgcAcquireMemSetEngine failed with 0xff");
    check(acquire[1] == 0x80001234u, "0xff did not set the engine bit");
    check(sceAgcAcquireMemSetEngine(acquire, 0) == 0, "sceAgcAcquireMemSetEngine failed");
    check(acquire[1] == 0x1234u, "acquire mem engine bit was not cleared to 0");
    const auto beforeAcquire = acquireStorage.words;
    expectFailure([&] { sceAgcAcquireMemSetEngine(nullptr, 0); });
    auto* misalignedAcquire = reinterpret_cast<std::uint32_t*>(reinterpret_cast<unsigned char*>(acquire) + 1);
    expectFailure([&] { sceAgcAcquireMemSetEngine(misalignedAcquire, 0); });
    check(acquireStorage.words == beforeAcquire, "invalid acquire engine patch modified packet memory");
    std::uint32_t wrongAcquire[8] = {0xc0065000u, 0x12345678u};
    check(sceAgcAcquireMemSetEngine(wrongAcquire, 0) == static_cast<int>(0x8a6c000c), "non-ACQUIRE_MEM packet did not return 0x8a6c000c");
    check(wrongAcquire[0] == 0xc0065000u && wrongAcquire[1] == 0x12345678u, "non-ACQUIRE_MEM packet was modified");
    check(sceAgcAcquireMemSetEngine(wrongAcquire, 1) == static_cast<int>(0x8a6c000c), "non-ACQUIRE_MEM packet did not return 0x8a6c000c with engine 1");
    check(wrongAcquire[0] == 0xc0065000u && wrongAcquire[1] == 0x12345678u, "non-ACQUIRE_MEM packet was modified with engine 1");

    std::uint32_t customLengthAcquire[4] = {Agc::Command::Header(0x58u, 4), 0x4321u, 0, 0};
    check(sceAgcAcquireMemSetEngine(customLengthAcquire, 1) == 0, "custom length acquire mem failed");
    check(customLengthAcquire[1] == 0x80004321u, "custom length acquire mem engine bit was not set");

    auto* acbAcquire = sceAgcAcbAcquireMem(&acquireStorage.buffer, 0x567u, nullptr, 0x1000, 0);
    check(acbAcquire[1] == 0x80000000u, "ACB acquire mem engine bit was not default 1");
    check(sceAgcAcquireMemSetEngine(acbAcquire, 0) == 0, "sceAgcAcquireMemSetEngine failed on ACB acquire");
    check(acbAcquire[1] == 0u, "ACB acquire mem engine bit was not cleared to 0");
}

void testEndOfPipePatches() {
    std::array<std::uint32_t, 8> packet{};
    packet[0] = Agc::Command::Header(0x49u, 8);
    packet[1] = 0xf0000fffu;
    packet[2] = 2u << 29u;
    check(sceAgcQueueEndOfPipeActionPatchData(packet.data(), 0x1122334455667788ull) == 0, "end-of-pipe data patch failed");
    check(packet[5] == 0x55667788u && packet[6] == 0x11223344u, "64-bit end-of-pipe data patch did not write both halves");
    packet[2] = 1u << 29u;
    check(sceAgcQueueEndOfPipeActionPatchData(packet.data(), 0x0badf00du) == 0, "32-bit end-of-pipe data patch failed");
    check(packet[5] == 0x0badf00du && packet[6] == 0u, "32-bit end-of-pipe data patch wrote the wrong words");
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(packet.data(), 0x100000000ull); });
    check(packet[5] == 0x0badf00du && packet[6] == 0u, "a rejected 32-bit data patch changed the packet");
    check(sceAgcQueueEndOfPipeActionPatchGcrCntl(packet.data(), 0x0a5u) == 0, "end-of-pipe GCR control patch failed");
    check(packet[1] == (0xf0000fffu | (0x0a5u << 12u)), "end-of-pipe GCR control patch did not keep the other control bits");
    check(sceAgcQueueEndOfPipeActionPatchGcrCntl(packet.data(), 0x100u) == 0 && packet[1] == (0xf0000fffu | (0x300u << 12u)), "end-of-pipe GCR control 0x100 did not gain 0x200");
    check(sceAgcQueueEndOfPipeActionPatchGcrCntl(packet.data(), 0x200u) == 0 && packet[1] == (0xf0000fffu | (0x200u << 12u)), "end-of-pipe GCR control 0x200 changed");
    const auto before = packet;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchGcrCntl(packet.data(), 0x1000u); });
    check(packet == before, "a rejected GCR control patch changed the packet");
    std::array<std::uint32_t, 8> gds{};
    gds[0] = Agc::Command::Header(0x49u, 8);
    gds[2] = 5u << 29u;
    gds[5] = 0x00020010u;
    const auto gdsBefore = gds;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(gds.data(), 1); });
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(gds.data(), 0x100000000ull); });
    check(gds == gdsBefore, "a rejected GDS release data patch changed the packet");
    check(sceAgcQueueEndOfPipeActionPatchData(gds.data(), 0) == 0 && gds == gdsBefore, "zero data patch changed the GDS offset and size");
    std::array<std::uint32_t, 8> interruptOnly{};
    interruptOnly[0] = Agc::Command::Header(0x49u, 8);
    interruptOnly[2] = 4u << 24u;
    const auto interruptBefore = interruptOnly;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(interruptOnly.data(), 1); });
    check(interruptOnly == interruptBefore, "a rejected interrupt-only data patch changed the packet");
    check(sceAgcQueueEndOfPipeActionPatchData(interruptOnly.data(), 0) == 0 && interruptOnly == interruptBefore, "zero data patch changed an interrupt-only release");
    interruptOnly[3] = 0x1000u;
    const auto addressed = interruptOnly;
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(interruptOnly.data(), 0); });
    check(interruptOnly == addressed, "an interrupt-only release with an address accepted a data patch");
    packet[0] = Agc::Command::Header(0x47u, 6);
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchData(packet.data(), 1); });
    expectFailure([&] { sceAgcQueueEndOfPipeActionPatchGcrCntl(packet.data(), 1); });
    packet[0] = before[0];
    check(packet == before, "a data or GCR control patch of another packet changed it");
}

struct AtomicGdsAllocation {
    Storage storage;
    std::uint32_t capacity = 15;
    std::uint32_t calls = 0;
    bool accepted = true;
};

bool APS5_VABI growAtomicGds(CommandBuffer* buffer, std::uint32_t count, void* userData) {
    auto& allocation = *static_cast<AtomicGdsAllocation*>(userData);
    check(count == 15, "atomic GDS allocation omitted packet or reserved words");
    ++allocation.calls;
    if (!allocation.accepted) return false;
    buffer->bottom = allocation.storage.words.data();
    buffer->top = buffer->bottom + allocation.capacity;
    buffer->cursor_up = buffer->bottom;
    buffer->cursor_down = buffer->top;
    return true;
}

void testAtomicGds() {
    Storage storage;
    storage.words.fill(0xdeadbeefu);
    storage.buffer.cursor_up += 2;
    auto* packet = sceAgcAcbAtomicGds_0900(&storage.buffer, 0xffffffffu, 1, 0xffffffffu, 0xffffffffu,
        0xabcd, 0xfedc, 0x12345678u, 0x87654321u, 0xfedcba9876543210ull, 0x0123456789abcdefull);
    const std::array<std::uint32_t, 11> expected{
        0xc0091d00u, 0x001500ffu, 0x13fu, 0xabcdu, 0xfedcu, 0x00340078u,
        0x87654321u, 0x76543210u, 0xfedcba98u, 0x89abcdefu, 0x01234567u};
    check(packet == storage.words.data() + 2, "atomic GDS returned the wrong packet address");
    check(std::equal(expected.begin(), expected.end(), packet), "atomic GDS packet or guest ABI mismatch");
    check(storage.buffer.cursor_up == packet + expected.size(), "atomic GDS did not advance by eleven words");
    check(storage.words[0] == 0xdeadbeefu && storage.words[1] == 0xdeadbeefu &&
        std::all_of(storage.words.begin() + 13, storage.words.end(), [](auto word) { return word == 0xdeadbeefu; }),
        "atomic GDS wrote outside its packet");

    const std::array<std::array<std::uint32_t, 3>, 9> controls{{
        {0, 0, 0}, {0, 1, 0x00020000u}, {0, 2, 0}, {0, 0xffffffffu, 0},
        {0x20u, 1, 0x00040020u}, {0x40u, 1, 0x00120040u},
        {0x200u, 1, 0x00030000u}, {0xfffffd00u, 0, 0}, {0xffu, 1, 0x001400ffu}}};
    for (const auto& entry : controls) {
        Storage controlStorage;
        auto* controlPacket = sceAgcAcbAtomicGds_0900(&controlStorage.buffer, entry[0], entry[1],
            0xfffffffeu, 0xffffffc0u, 0, 0, 0xff00ff00u, 0, 0, 0);
        std::array<std::uint32_t, 11> controlExpected{};
        controlExpected[0] = 0xc0091d00u;
        controlExpected[1] = entry[2];
        check(std::equal(controlExpected.begin(), controlExpected.end(), controlPacket), "atomic GDS control or field masking mismatch");
    }

    auto emit = [](CommandBuffer* buffer) {
        return sceAgcAcbAtomicGds_0900(buffer, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    };
    Storage exact;
    exact.buffer.cursor_down = exact.words.data() + 15;
    exact.buffer.reserved_dw = 4;
    check(emit(&exact.buffer) == exact.words.data() && exact.buffer.cursor_up == exact.words.data() + 11,
        "atomic GDS rejected an exact fit with reserved space");
    const auto exactBefore = exact.words;
    expectFailure([&] { emit(&exact.buffer); });
    check(exact.words == exactBefore && exact.buffer.cursor_up == exact.words.data() + 11,
        "atomic GDS overwrote reserved space");
    Storage exhausted;
    exhausted.buffer.cursor_down = exhausted.words.data() + 10;
    const auto before = exhausted.words;
    expectFailure([&] { emit(&exhausted.buffer); });
    check(exhausted.words == before && exhausted.buffer.cursor_up == exhausted.words.data(),
        "failed atomic GDS allocation modified the buffer");
    expectFailure([&] { emit(nullptr); });

    Storage noDown;
    noDown.buffer.top = noDown.words.data() + 11;
    noDown.buffer.cursor_down = nullptr;
    check(emit(&noDown.buffer) == noDown.words.data() && noDown.buffer.cursor_up == noDown.buffer.top,
        "atomic GDS did not honor a buffer with no down cursor");

    AtomicGdsAllocation allocation;
    CommandBuffer growing{nullptr, nullptr, nullptr, nullptr, growAtomicGds, &allocation, 4};
    check(emit(&growing) == allocation.storage.words.data() && allocation.calls == 1 &&
        growing.cursor_up == allocation.storage.words.data() + 11, "atomic GDS did not use the guest allocation callback");
    const std::array<std::uint32_t, 11> zeroPacket{0xc0091d00u};
    check(std::equal(zeroPacket.begin(), zeroPacket.end(), allocation.storage.words.begin()),
        "atomic GDS callback allocation produced the wrong packet");
    for (const bool accepted : {false, true}) {
        AtomicGdsAllocation failure;
        failure.accepted = accepted;
        failure.capacity = 14;
        const auto failureBefore = failure.storage.words;
        CommandBuffer failed{nullptr, nullptr, nullptr, nullptr, growAtomicGds, &failure, 4};
        expectFailure([&] { emit(&failed); });
        check(failure.calls == 1 && failure.storage.words == failureBefore &&
            failed.cursor_up == (accepted ? failure.storage.words.data() : nullptr),
            "atomic GDS wrote a packet after failed or insufficient allocation");
    }
}

void testCopyDataAndComputeEvents() {
    Storage graphics;
    const auto* copy = sceAgcDcbCopyData(&graphics.buffer, 4, 1, 0x1122334450ull, 0xb, 2, 0x12345678u, 0, 1);
    const std::array<std::uint32_t, 6> graphicsExpected{0xc0044000u, 0x42104205u, 0x12345678u, 0, 0x22334450u, 0x11u};
    check(copy == graphics.words.data() && std::equal(graphicsExpected.begin(), graphicsExpected.end(), graphics.words.begin()), "graphics COPY_DATA packet mismatch");
    Storage wide;
    sceAgcDcbCopyData(&wide.buffer, 4, 0, 0x1000, 0xa, 0, 0x100000000ull, 1, 0);
    check(wide.words[1] == 0x00010205u && wide.words[2] == 0 && wide.words[3] == 1, "a 64-bit immediate COPY_DATA lost its high word");
    Storage compute;
    sceAgcAcbCopyData(&compute.buffer, 2, 0, 0x4000, 5, 0, 7, 0, 0);
    const std::array<std::uint32_t, 6> computeExpected{0xc0044000u, 0x205u, 7, 0, 0x4000u, 0};
    check(std::equal(computeExpected.begin(), computeExpected.end(), compute.words.begin()), "compute COPY_DATA packet mismatch");
    Storage rejected;
    rejected.words.fill(0xa5a5a5a5u);
    const auto rejectedWords = rejected.words;
    const auto* rejectedCursor = rejected.buffer.cursor_up;
    expectFailure([&] { sceAgcDcbCopyData(&rejected.buffer, 4, 4, 0x1000, 0xa, 0, 1, 0, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbCopyData(&rejected.buffer, 4, 0, 0x1000, 0xa, 4, 1, 0, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcAcbCopyData(&rejected.buffer, 2, 0, 0x4000, 5, 0, 1, 2, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcAcbCopyData(&rejected.buffer, 2, 0, 0x4000, 5, 0, 1, 0, 2); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    check(sceAgcDcbCopyDataGetSize() == 24 && sceAgcAcbCopyDataGetSize() == 24, "COPY_DATA packet sizes");
    Storage events;
    sceAgcAcbEventWrite(&events.buffer, 7, nullptr);
    sceAgcAcbEventWrite(&events.buffer, 0x16, nullptr);
    const std::array<std::uint32_t, 4> eventsExpected{0xc0004600u, 0x407u, 0xc0004600u, 0x16u};
    check(std::equal(eventsExpected.begin(), eventsExpected.end(), events.words.begin()), "compute EVENT_WRITE packet mismatch");
    Storage refused;
    refused.words.fill(0xa5a5a5a5u);
    const auto refusedWords = refused.words;
    const auto* refusedCursor = refused.buffer.cursor_up;
    expectFailure([&] { sceAgcAcbEventWrite(&refused.buffer, 0x40, nullptr); });
    check(refused.words == refusedWords && refused.buffer.cursor_up == refusedCursor, "a refused packet changed the command buffer");
    check(sceAgcAcbEventWriteGetSize(7) == 8, "compute EVENT_WRITE packet size");
}

void testDebugRaiseException() {
    int result = -1;
    try {
        result = sceAgcDebugRaiseException(0x1234abcdu);
    } catch (const std::exception& error) {
        throw std::runtime_error(std::string("debug exception stopped the caller: ") + error.what());
    }
    check(result == 0, "debug exception did not return 0");
}

void testDefaults() {
    std::uint32_t state = 0x12345678;
    check(sceAgcInit_0090(&state, 8) == 0 && state == 0x12345678, "AGC initialization failed or modified caller state");
    check(sceAgcInit_0090(&state, 13) == 0 && state == 0x12345678, "AGC version 13 initialization changed caller state");
    expectFailure([] { sceAgcInit_0090(nullptr, 8); });
    check(sceAgcInit_0090(&state, 14) == 0 && state == 0x12345678, "out-of-range AGC initialization version changed caller state");
    check(sceAgcInit(8) == 0, "AGC version initialization failed");
    check(sceAgcInit(13) == 0, "AGC version 13 initialization failed");
    check(sceAgcInit(14) == 0, "out-of-range AGC version did not return success");
    check(sceAgcInit(0xffffffffu) == 0, "maximum AGC version did not return success");
    check(sceAgcInit(0xffffc278u) == 0, "pointer-valued AGC argument did not return success");
    for (std::uint32_t version = 0; version < 14; ++version) {
        for (const bool internal : {false, true}) {
            auto* first = Agc::Command::GetRegisterDefaults(version, internal, __func__);
            check(first != nullptr && first == Agc::Command::GetRegisterDefaults(version, internal, __func__), "unstable register defaults pointer");
        }
    }
    auto* internalDefaults = sceAgcGetRegisterDefaultsInternal();
    check(internalDefaults != nullptr && internalDefaults == Agc::Command::GetRegisterDefaults(0, true, __func__) && internalDefaults == sceAgcGetRegisterDefaults2Internal(0), "internal register defaults are not the baseline internal table");
    check(internalDefaults != sceAgcGetRegisterDefaults(), "internal register defaults returned the public table");
    constexpr int kInvalidArgument = static_cast<int>(0x80890001u);
    std::array<std::uint32_t, 512> flatCxBuffer{};
    check(sceAgcGetDefaultCxStateFlat(nullptr, sizeof(flatCxBuffer)) == kInvalidArgument, "null destination was accepted");
    check(sceAgcGetDefaultCxStateFlat(flatCxBuffer.data(), 0) == 0, "zero size copy failed");
    check(sceAgcGetDefaultCxStateFlat(flatCxBuffer.data(), sizeof(flatCxBuffer)) == 0, "flat CX state default retrieval failed");
    check(flatCxBuffer[0x001] == 0x11000100u, "flat CX state register 0x001 mismatch");
    check(flatCxBuffer[0x007] == 0x0000ffffu, "flat CX state register 0x007 mismatch");
    check(flatCxBuffer[0x12d] == 0x3f800000u, "flat CX state register 0x12d mismatch");
    check(flatCxBuffer[0x1e0] == 0x20010001u, "flat CX state register 0x1e0 mismatch");
    std::array<std::uint32_t, 513> overBuffer{};
    overBuffer[512] = 0x12345678u;
    check(sceAgcGetDefaultCxStateFlat(overBuffer.data(), sizeof(overBuffer)) == 0, "oversized copy failed");
    check(overBuffer[512] == 0x12345678u, "oversized copy overflowed buffer");
    check(Agc::Command::GetDefaultCxStateFlat(nullptr, sizeof(flatCxBuffer)) == kInvalidArgument, "null command destination was accepted");
    check(Agc::Command::GetDefaultCxStateFlat(flatCxBuffer.data(), sizeof(flatCxBuffer)) == 0, "command flat CX state retrieval failed");
    expectFailure([] { Agc::Command::GetRegisterDefaults(14, false, __func__); });
    expectFailure([] { Agc::Command::GetRegisterDefaults(0xffffffffu, true, __func__); });
}

constexpr std::size_t PairEntryBytes = 8;
constexpr std::size_t CompactEntryBytes = 12;

std::uint32_t colourTargetBlock(const void* root, std::size_t entryBytes) {
    const auto* bytes = static_cast<const unsigned char*>(root);
    ShaderRegister** contextBlocks = nullptr;
    const unsigned char* types = nullptr;
    std::uint32_t count = 0;
    std::memcpy(&contextBlocks, bytes, sizeof(contextBlocks));
    std::memcpy(&types, bytes + 0x30, sizeof(types));
    std::memcpy(&count, bytes + 0x38, sizeof(count));
    check(contextBlocks != nullptr && types != nullptr && count > 0, "register defaults root has no context blocks or types");
    std::uint32_t contexts = 0;
    std::uint32_t matches = 0;
    std::uint32_t block = 0;
    for (std::uint32_t entry = 0; entry < count; ++entry) {
        std::uint32_t key = 0;
        std::uint32_t bankIndex = 0;
        std::memcpy(&key, types + entry * entryBytes, sizeof(key));
        std::memcpy(&bankIndex, types + entry * entryBytes + 4, sizeof(bankIndex));
        bankIndex &= 0x3ffu;
        if ((bankIndex & 3u) == 0)
            ++contexts;
        if (key != 0x38e92c91u)
            continue;
        check((bankIndex & 3u) == 0, "MRT0 defaults are not in the context bank");
        block = bankIndex >> 2;
        ++matches;
    }
    check(matches == 1 && block < contexts && contextBlocks[block] != nullptr, "MRT0 defaults key is missing, repeated or outside the context blocks");
    constexpr std::array<std::uint32_t, 16> offsets{0x318, 0x31b, 0x31c, 0x31d, 0x31e, 0x31f, 0x321, 0x323, 0x324, 0x325, 0x390, 0x398, 0x3a0, 0x3a8, 0x3b0, 0x3b8};
    for (std::size_t i = 0; i < offsets.size(); ++i)
        check(contextBlocks[block][i].offset == offsets[i], "MRT0 defaults block does not hold the colour target registers");
    return block;
}

void testDefaultsTypes() {
    const auto* legacy = sceAgcGetRegisterDefaults();
    check(legacy != sceAgcGetRegisterDefaults2(13), "legacy register defaults reused the compact versioned table");
    check(colourTargetBlock(legacy, PairEntryBytes) == 78, "MRT0 defaults are not block 78 of the 137-entry table");
    check(colourTargetBlock(sceAgcGetRegisterDefaults2(13), CompactEntryBytes) == 78, "versioned MRT0 defaults are not block 78 of the compact 137-entry table");
    check(colourTargetBlock(sceAgcGetRegisterDefaults2(10), CompactEntryBytes) == 73, "versioned MRT0 defaults are not block 73 of the compact 128-entry table");
    for (std::uint32_t version = 4; version < 14; ++version)
        colourTargetBlock(sceAgcGetRegisterDefaults2(version), CompactEntryBytes);

    const auto checkCompactTypes = [](const void* root, std::uint32_t count, std::uint32_t key,
                                      std::uint32_t packedType, std::uint32_t extra) {
        const auto* bytes = static_cast<const unsigned char*>(root);
        const std::uint32_t* types = nullptr;
        std::uint32_t actualCount = 0;
        std::memcpy(&types, bytes + 0x30, sizeof(types));
        std::memcpy(&actualCount, bytes + 0x38, sizeof(actualCount));
        check(types != nullptr && actualCount == count, "versioned register defaults have an invalid compact type table");
        check(types[0] == key && types[1] == packedType && types[2] == extra,
              "versioned register defaults did not preserve their compact type entry");
    };
    checkCompactTypes(sceAgcGetRegisterDefaults2(0), 150, 0xe24f806du, 0x00040400u, 0);
    checkCompactTypes(sceAgcGetRegisterDefaults2(10), 128, 0xe24f806du, 0x00040400u, 0);
    checkCompactTypes(sceAgcGetRegisterDefaults2Internal(0), 15, 0xf58fea31u, 0x00040400u, 0);
}

void testDispatchPackets() {
    Storage graphics;
    const auto* indirect = sceAgcDcbDispatchIndirect(&graphics.buffer, 0x40, 0x8);
    check(indirect == graphics.words.data() && graphics.words[0] == 0xc0011600u && graphics.words[1] == 0x40u && graphics.words[2] == 0x49u, "graphics DISPATCH_INDIRECT packet mismatch");
    Storage compute;
    const auto* arguments = reinterpret_cast<const volatile void*>(0x123456789abcull);
    sceAgcAcbDispatchIndirect(&compute.buffer, arguments, 0x2000u);
    const std::array<std::uint32_t, 4> computeExpected{0xc0021600u, 0x56789abcu, 0x1234u, 0x2041u};
    check(std::equal(computeExpected.begin(), computeExpected.end(), compute.words.begin()), "compute DISPATCH_INDIRECT packet mismatch");
    Storage direct;
    sceAgcCbDispatch(&direct.buffer, 7, 3, 1, 0x8000u);
    const std::array<std::uint32_t, 5> directExpected{0xc0031500u, 7, 3, 1, 0x8041u};
    check(std::equal(directExpected.begin(), directExpected.end(), direct.words.begin()), "DISPATCH_DIRECT packet mismatch");
    Storage rejected;
    rejected.words.fill(0xa5a5a5a5u);
    const auto rejectedWords = rejected.words;
    const auto* rejectedCursor = rejected.buffer.cursor_up;
    expectFailure([&] { sceAgcCbDispatch(&rejected.buffer, 1, 1, 1, 0x100u); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcAcbDispatchIndirect(&rejected.buffer, reinterpret_cast<const volatile void*>(0x1002ull), 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcAcbDispatchIndirect(&rejected.buffer, nullptr, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    check(sceAgcDcbDispatchIndirectGetSize() == 12 && sceAgcAcbDispatchIndirectGetSize() == 16 && sceAgcCbDispatchGetSize() == 20, "dispatch packet sizes");
}

void testEventWrite() {
    Storage storage;
    const auto* samplePacket = sceAgcDcbEventWrite(&storage.buffer, 0x38, reinterpret_cast<const void*>(0x1000));
    check(samplePacket == storage.words.data(), "incorrect event 0x38 return pointer");
    check(storage.words[0] == 0xc0024600u, "incorrect event 0x38 packet header");
    check(storage.words[1] == (0x100u | 0x38u), "incorrect event 0x38 first payload word");
    check(storage.words[2] == 0x1000u, "incorrect event 0x38 low address word");
    check(storage.words[3] == 0u, "incorrect event 0x38 high address word");
    check(sceAgcDcbEventWriteGetSize(0x38) == 16, "incorrect event 0x38 size");
    check(sceAgcDcbEventWriteGetSize(0x39) == 16, "incorrect event 0x39 size");

    Storage sample39;
    sceAgcDcbEventWrite(&sample39.buffer, 0x39, reinterpret_cast<const void*>(0x2008));
    check(sample39.words[0] == 0xc0024600u && sample39.words[1] == (0x100u | 0x39u) && sample39.words[2] == 0x2008u && sample39.words[3] == 0u, "incorrect event 0x39 packet");

    expectFailure([&] { sceAgcDcbEventWrite(&storage.buffer, 0x38, reinterpret_cast<const void*>(0x1001)); });
    expectFailure([&] { sceAgcDcbEventWrite(&storage.buffer, 0x40, nullptr); });

    Storage partialFlush;
    sceAgcDcbEventWrite(&partialFlush.buffer, 7, nullptr);
    check(partialFlush.words[0] == 0xc0004600u && partialFlush.words[1] == 0x407u, "incorrect event 7 partial flush packet");
    check(sceAgcDcbEventWriteGetSize(7) == 8, "incorrect event 7 size");

    Storage partialFlush15;
    sceAgcDcbEventWrite(&partialFlush15.buffer, 15, nullptr);
    check(partialFlush15.words[0] == 0xc0004600u && partialFlush15.words[1] == 0x40fu, "incorrect event 15 partial flush packet");

    Storage partialFlush16;
    sceAgcDcbEventWrite(&partialFlush16.buffer, 16, nullptr);
    check(partialFlush16.words[0] == 0xc0004600u && partialFlush16.words[1] == 0x410u, "incorrect event 16 partial flush packet");

    Storage cacheFlushNull;
    sceAgcDcbEventWrite(&cacheFlushNull.buffer, 0x16, nullptr);
    check(cacheFlushNull.words[0] == 0xc0004600u && cacheFlushNull.words[1] == 0x16u, "incorrect event 0x16 null address packet");
    check(sceAgcDcbEventWriteGetSize(0x16) == 8, "incorrect event 0x16 size");

    Storage cacheFlushWithAddress;
    sceAgcDcbEventWrite(&cacheFlushWithAddress.buffer, 0x16, reinterpret_cast<const void*>(0x2d2a10000ull));
    check(cacheFlushWithAddress.words[0] == 0xc0004600u && cacheFlushWithAddress.words[1] == 0x16u, "incorrect event 0x16 with address packet");
}

void testAcquireMem() {
    Storage storage;
    const auto* base = reinterpret_cast<const volatile void*>(0x1234567890ull);
    const auto* packet = sceAgcDcbAcquireMem(&storage.buffer, 0, 0, 0x1234u, base, 0x1000, 400);
    const std::array<std::uint32_t, 8> expected{0xc0065800u, 0, 0x11, 0, 0x12345678u, 0, 25, 0x1234u};
    check(packet == storage.words.data() && std::equal(expected.begin(), expected.end(), storage.words.begin()), "acquire packet does not round its range outward to 256 bytes");
    const std::array<std::pair<std::uint32_t, std::uint32_t>, 18> polls{{{0, 0}, {1, 0}, {15, 0}, {16, 1}, {39, 2}, {40, 2}, {80, 5}, {160, 10}, {400, 25}, {1000, 62}, {4000, 250}, {100000, 6250}, {1000000, 62500}, {0x100000u, 0xffffu}, {0xfffff0u, 0xffffu}, {0x1000000u, 0xffffu}, {0xffffffffu, 0xffffu}, {0x44444444u, 0xffffu}}};
    for (const auto& [pollCycles, pollWord] : polls) {
        Storage measured;
        sceAgcDcbAcquireMem(&measured.buffer, 0, 0, 0x4380u, base, 0x1000, pollCycles);
        check(measured.words[6] == pollWord, "acquire poll word is not the poll cycles shifted right by four");
    }
    const std::array<std::pair<std::uint32_t, std::uint32_t>, 15> controls{{{0, 0}, {1, 1}, {0x80, 0x80}, {0x4000, 0xc000}, {0x4380, 0xc380}, {0x8000, 0x8000}, {0xc380, 0xc380}, {0x1234, 0x1234}, {0x7ffff, 0x7ffff}, {0x4001, 0xc001}, {0x9000, 0x9000}, {0xd000, 0xd000}, {0x4300, 0xc300}, {0x77fff, 0x7ffff}, {0x10000, 0x10000}}};
    for (const auto& [gcrControl, gcrWord] : controls) {
        Storage measured;
        sceAgcDcbAcquireMem(&measured.buffer, 0, 0, gcrControl, base, 0x1000, 0xa0);
        check(measured.words[7] == gcrWord, "acquire cache control word does not set bit 15 with bit 14");
    }
    Storage whole;
    sceAgcDcbAcquireMem(&whole.buffer, 0, 0, 0, base, 0xffffffffffffffffull, 0);
    check(whole.words[0] == 0xc0065800u && whole.words[2] == 0 && whole.words[4] == 0 && whole.words[6] == 0, "an unbounded acquire did not cover the whole address space");
    Storage large;
    sceAgcDcbAcquireMem(&large.buffer, 0, 0, 0, base, (1ull << 40u) + 1u, 0);
    check(large.words[2] == 0 && large.words[4] == 0, "an acquire over 1 TiB did not cover the whole address space");
    Storage exact;
    sceAgcDcbAcquireMem(&exact.buffer, 0, 0, 0, base, 1ull << 40u, 0);
    check(exact.words[2] == 0 && exact.words[4] == 0, "an acquire of exactly 1 TiB did not cover the whole address space");
    Storage encodable;
    sceAgcDcbAcquireMem(&encodable.buffer, 0, 0, 0, nullptr, (1ull << 40u) - 0x100u, 0);
    check(encodable.words[2] == 0xffffffffu && encodable.words[4] == 0, "an acquire just below 1 TiB was not encoded as its exact size");
    Storage roundedUp;
    sceAgcDcbAcquireMem(&roundedUp.buffer, 0, 0, 0, reinterpret_cast<const volatile void*>(0x1ull), (1ull << 40u) - 0xffu, 0);
    check(roundedUp.words[2] == 0 && roundedUp.words[4] == 0, "an acquire rounded up to 1 TiB did not cover the whole address space");
    Storage asynchronous;
    sceAgcAcbAcquireMem(&asynchronous.buffer, 0x55u, base, 0x100, 80);
    const std::array<std::uint32_t, 8> compute{0xc0065800u, 0x80000000u, 2, 0, 0x12345678u, 0, 5, 0x55u};
    check(std::equal(compute.begin(), compute.end(), asynchronous.words.begin()), "the asynchronous compute acquire did not select engine 1 with no CB/DB operation");
    Storage rejected;
    rejected.words.fill(0xa5a5a5a5u);
    const auto rejectedWords = rejected.words;
    const auto* rejectedCursor = rejected.buffer.cursor_up;
    expectFailure([&] { sceAgcDcbAcquireMem(&rejected.buffer, 2, 0, 0, base, 0x100, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    expectFailure([&] { sceAgcDcbAcquireMem(&rejected.buffer, 0, 0, 0x80000u, base, 0x100, 0); });
    check(rejected.words == rejectedWords && rejected.buffer.cursor_up == rejectedCursor, "a refused packet changed the command buffer");
    Storage saturatedAsync;
    sceAgcAcbAcquireMem(&saturatedAsync.buffer, 0, base, 0x100, 0xffffffffu);
    check(saturatedAsync.words[6] == 0xffffu, "the asynchronous compute acquire did not saturate the poll word at 0xffff");
    check(sceAgcDcbAcquireMemGetSize() == 32 && sceAgcAcbAcquireMemGetSize() == 32, "acquire packet size");
}

template <typename TWrite>
std::size_t writtenBytes(TWrite write) {
    Storage storage;
    const auto* start = storage.buffer.cursor_up;
    write(storage.buffer);
    return static_cast<std::size_t>(storage.buffer.cursor_up - start) * sizeof(std::uint32_t);
}

void testPacketSizes() {
    alignas(64) std::uint32_t memory[16]{};
    const std::array<std::uint32_t, 3> values{1, 2, 3};
    check(writtenBytes([](CommandBuffer& buffer) { sceAgcDcbDrawIndexAuto(&buffer, 17, 0); }) == sceAgcDcbDrawIndexAutoGetSize(), "auto index draw size differs from its packet");
    check(writtenBytes([](CommandBuffer& buffer) { sceAgcDcbDrawIndexIndirect(&buffer, 0x40, 0); }) == sceAgcDcbDrawIndexIndirectGetSize(), "indexed indirect draw size differs from its packet");
    check(writtenBytes([](CommandBuffer& buffer) { sceAgcDcbDrawIndirectMulti(&buffer, 0x40, 0, 5, nullptr, 16, 0); }) == sceAgcDcbDrawIndirectMultiGetSize(), "indirect multi draw size differs from its packets");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcDcbSetIndexBuffer(&buffer, reinterpret_cast<std::uintptr_t>(memory)); }) == sceAgcDcbSetIndexBufferGetSize(), "index buffer size differs from its packet");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcDcbGetLodStats(&buffer, 0, memory, sizeof(memory), 0, 0, 0, 0); }) == sceAgcDcbGetLodStatsGetSize(), "LOD statistics size differs from its packet");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcDcbCondExec(&buffer, memory, 4); }) == sceAgcDcbCondExecGetSize(), "graphics conditional execution size differs from its packet");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcAcbCondExec(&buffer, memory, 4); }) == sceAgcAcbCondExecGetSize(), "compute conditional execution size differs from its packet");
    check(writtenBytes([](CommandBuffer& buffer) { sceAgcAcbRewind(&buffer, 0); }) == sceAgcAcbRewindGetSize(), "compute rewind size differs from its packet");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcCbSetShRegisterRangeDirect(&buffer, 0x90, values.data(), values.size()); }) == sceAgcCbSetShRegisterRangeDirectGetSize(values.size()), "shader register range size differs from its packet");
    check(writtenBytes([&](CommandBuffer& buffer) { sceAgcCbSetUcRegisterRangeDirect(&buffer, 0x90, values.data(), values.size()); }) == sceAgcCbSetUcRegisterRangeDirectGetSize(values.size()), "user config register range size differs from its packet");
}

}

int main(int argc, char** argv) {
    try {
        if (argc == 2 && std::strcmp(argv[1], "defaults") == 0) {
            testDefaults();
            testDefaultsTypes();
            LibcRunShutdown_nid_postfix();
            std::puts("AGC initialization tests passed");
            return 0;
        }
        testPackets();
        testEventWrite();
        testAcquireMem();
        testNop();
        testDispatchPackets();
        testClearState();
        testIndexedIndirectDraws();
        testTagHeaders();
        testMarkers();
        testJumpTargetPatch();
        testMarkerSpans();
        testWorkloads();
        testEndOfPipeAddressPatch();
        testWorkloadStreams();
        testIndexBuffer();
        testDrawPackets();
        testIndexIndirectArgs();
        testIndirectBase();
        testContextState();
        testFlowPackets();
        testFlip();
        testRegisters();
        testIndirectRegisterPatches();
        testRegisterRange();
        testPacketPayloadAddress();
        testMemory();
        testEndOfPipePatches();
        testAtomicGds();
        testDebugRaiseException();
        testCopyDataAndComputeEvents();
        testPacketSizes();
        testDefaults();
        testDefaultsTypes();
        LibcRunShutdown_nid_postfix();
        std::puts("AGC command tests passed");
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        try { LibcRunShutdown_nid_postfix(); }
        catch (const std::exception& shutdown) { std::fprintf(stderr, "shutdown: %s\n", shutdown.what()); }
        return 1;
    }
}
